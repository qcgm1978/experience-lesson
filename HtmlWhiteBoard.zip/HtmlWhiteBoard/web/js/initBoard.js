/**
 * Created by Administrator on 2016/5/23.
 */
var constants={//静态常量
    COLORTEA:'#FF0000',
    COLORSTU:'#0078FF',
    COLORSTUSIGN:'#FFFF00',
    COLORTEASIGN:'#FF0000',
    COLORTARGET:'#0000FF',
    timer:new Date(),
    Arr_scroll:[],
    TEATYPE:[1,4,6,7],
    STUTYPE:['stu','cc']
};

var ClassConfInit=(function () {
    var obj_ClassData=null;//存储课程信息
    var obj_UserData=null;//存储用户信息
    var obj_HostData=null;//存储宿主信息
    var obj_URLData=null;//存储访问地址信息
    var data={//本地维护信息
        'obj_UserData':null,
        'versionType':'old',//版本类型 兼容老版本
        'HostType':'cef3',//宿主
        'name_login':'stu',//登陆身份
        'Class1V1':false,//课程类型
        'texttype':'pdf',//教材类型
        'courseyoung':false,//是否为青少
        'url':'',//课件地址
        'candraw':false,//是否可绘制
        'classtype':null,//课程类型
        'completeCourse':false,//课件是否加载完毕
        'Arr_init':[],//当课件未加载完毕时存储服务器信息的缓冲区
        'turnPage':true,//是否可翻页
        'timeArr':[],//已抛弃
        'wid':0,
        'conf':{//模块信息
            'sigh_contain':false,//课件模块
            'sign_page':false,//翻页模块
            'sign_tools':false,//工具条模块
            'sign_draw':false,//绘制模块
            'sign_scroll':false,//老师端提示文字滚动模块
            'sign_fixdata':false
        },
        'course':{
            //课程教材属性信息
            'width':500,
            'height':500
        },
        'canvas':{
            //绘制区模块信息
            'width':500,
            'height':500
        },
        'pencil':{
            //画笔
            'size':3,
            'size_sign':20,
            'color':constants.COLORSTU,
            'color_sign':constants.COLORSTUSIGN,
            'color_target':constants.COLORTARGET,
            'rubbersize':30
        },
        'font':{
            //文字
            'fontstyle':'宋体',
            'fontSize':25,
            'color':constants.COLORSTU
        },
        'tea':{
            //
            'pageNum':1,
            'login':false
        },
        'page':{
            //页码信息
            'curpageNum':1,
            'count':5
        },
        'stu':{
            //学生信息  已抛弃
            'pageNum':1,
            'login':false
        },
        'tools':{
            //工具条信息
            'pen':false,//画笔
            'signpen':false,//荧光笔
            'rec':false,//矩形
            'rub':false,//旧版橡皮擦
            'newrub':false,//新版橡皮擦
            'text':false,//文字
            'draft':false,//拖拽
            'back':false,//回退
            'clear':false//清空
        },
        'mouse':{
            //鼠标信息
            'x':0,
            'y':0
        },
        'topScroll_changed':0,//用于辅助判断滚动条是否滚动有效
        'tip_update':true//实现未知功能的升级提示
    };
    var tea_id=[1,4,6,7];

    var route= function (obj,s) {//路由功能  导航舒适化加载的模块
        switch (s){
            case 0:
                obj_ClassData=obj;
                break;
            case 1:
                obj_UserData=obj;
                break;
            case 2:
                obj_HostData=obj;
                break;
            case 3:
                obj_URLData=obj;
                break;
            default :
                break;
        }
        if(obj_ClassData&&obj_UserData&&obj_HostData&&obj_URLData){//判断是否接收到全部初始化信息

            data.obj_UserData=obj_UserData;
            data.versionType=(obj_HostData.versionType!=1?'old':'new');

            data.name_login=(tea_id.indexOf(obj_ClassData.courserole)!=-1)?'tea':'stu';

            if(obj_ClassData.courserole==64){//新加cc类型
                data.name_login='cc';
            }

            data.Class1V1=(obj_ClassData.coursestyle==0)?true:false;

            data.classtype=obj_ClassData.metrialtype;

            data.courseyoung=(obj_HostData.showtype=='teen')?true:false;

            data.texttype=(obj_HostData.textType==0)?'pdf':'ppt';

            data.url=obj_URLData.url;

            if(obj_HostData.toolsconf){
                data.tools=obj_HostData.toolsconf;
                if(data.tools.rub&&data.tools.newrub){//容错处理，防止后台配置错误
                    if(data.tools.draft){
                        data.tools.rub=false;
                    }else{
                        data.tools.newrub=false;
                    }
                }

                if(data.tools.draft||data.tools.newrub){//规则，何时可以双击修改文字
                    data.versionType='new';
                }
            }

            data.turnPage=(obj_ClassData.CanTurnPage==1)?true:false;

            if(data.name_login=='tea'){
                data.pencil.color=constants.COLORTEA;
                data.pencil.color_sign=constants.COLORTEASIGN;
                data.tea.login=true;
            }

            if(((data.name_login=='stu'&&data.Class1V1)||data.name_login=='tea')&&data.name_login!='cc'){//允许学生绘制的逻辑
                data.candraw=true;
            }
            window.addEventListener('resize', function (event) {//监听缩放
                //changePage();
                throttle(ClassConfInit.resizeSet);
            });
            CreatePageContain();

            //if(obj_HostData.tipdata.fixdata&&data.name_login=='tea'){
            //    CreateFixeddata();
            //    $('#data_close').bind('click', function (e) {
            //        var obj={
            //            'type':'fixdata',
            //            'status':'close'
            //        };
            //        comm_type_send_set('tipdata',JSON.stringify(obj));
            //        $('.fixdata_tea').css('display','none');
            //        e.preventDefault();
            //        e.stopPropagation();
            //    });
            //}
            //兼容ppt和pdf以及之后的其他教材类型
            if(data.texttype=='pdf'){
                //pdf
                CreateCourse('pdf');
                if(data.Class1V1||(!data.Class1V1&&data.name_login=='stu')){
                    $('#mouseTea').css('display','block');
                }
                CreateDrawBoard();//加载绘制区
                setInterval(function () {
                    comm_send.UpdateMouse();
                    scroll_wheel();
                },1000);
                if(data.courseyoung){
                    //if(obj_HostData.tipdata.fixdata&&data.name_login=='tea'){
                    //    $('.fixdata_tea').css('top','0px');
                    //    $('.fixdata_tea').css('cursor','url(./images/young_normal222.png) 25 16,auto');
                    //}
                }else{
                    if(data.turnPage){//是否可翻页
                        CreatePageMostTurnpage();//加载翻页模块
                    }
                    if(data.name_login=='tea'||(data.candraw)){
                        CreatePageMostTools();//加载工具条模块
                    }
                    if(data.name_login=='tea'){
                        //CreateScrolldata();
                        //scroll_tea();
                    }
                    //if(obj_HostData.tipdata.fixdata&&data.name_login=='tea'){
                    //    $('.fixdata_tea').css('top','40px');
                    //    $('.fixdata_tea').css('cursor','url(./images/young_normal222.png) 25 16,auto');
                    //}
                }
            }else{
                //ppt
            }
            if(obj_HostData.language=='en'){
                titleTip();
            }
            /*ppt_______________________________________________________________________*/
            if(data.name_login=='stu'){
                $('#tool_ppt_control').removeClass('tool_ppt_practice');
                $('#tool_ppt_control').removeClass('tool_ppt_class');
            }
            /*ppt_______________________________________________________________________*/
            reinit();

            $('#update_cue').bind('click', function (e) {
                if(e.target.id=='cue_close'){
                    $('#update_cue').css('display','none');
                }else if(e.target.id=='cue_stop'){
                    ClassConfInit.data.tip_update=false;
                    $('#update_cue').css('display','none');
                }
                else if(e.target.id=='cue_update'){
                    $('#update_cue').css('display','none');
                }
            });
        }
    };

    var reinit= function () {
        data.wid=$('.item_title').width();
        var wid=$('#mainContainer').width(),
            hei=$('#mainContainer').height();
        if(data.conf.sigh_contain){//如果存在这个模块
            data.course.width=wid;
            if(data.conf.sign_page){//如果存在这个模块
                data.course.height=hei-40;
                $('#workSpace').height(hei-40);
            }else{//不存在
                data.course.height=hei;
                $('#workSpace').height(hei);
            }
            if(data.conf.sign_draw){//如果存在这个模块
                WEBTools.review();
            }else{//不存在

            }
            tools.init();
        }else{//不存在

        }
    }
    var resizeSet= function () {//用于自适应
        reinit();
        //$('#showDomain').css({
        //    'width': $('#workContainer').width(),
        //    'height': $('#workContainer').height()
        //});
        commParIf.resetchild();
        commParIf.setresize();
    }

    return{
        'route': function (obj,s) {
            route(obj,s);
        },
        'data':data,
        'resizeSet':resizeSet
    }
})();

var commParIf=(function () {
    var parentCon=null;
    var init= function (s) {
        //之后尽量避免使用这种方法
        if(!s){//s为空  初始化parentCon
            parentCon=$(window.parent.document).contents().find("#showDomain")[0].contentWindow;
        }else{
            //s不为空  pdf加载完毕的初始化操作
            ClassConfInit.data.completeCourse=true;
            ClassConfInit.data.page.count=s;
            if(ClassConfInit.data.courseyoung){//如果存在这个模块
                comm_send.UpdateYoungPage(1,s);
                parentCon.document.getElementById('mainContainer').style.cursor='url(images/young_normal.png) 25 15,auto';
            }else{
                //parentCon.document.getElementById('mainContainer').style.cursor='url(images/normal.png) 0 0,auto';
            }
            if(ClassConfInit.data.conf.sign_page){//如果存在这个模块
                $('#numPages').text('/ '+s);
                $('#toolbar_id').css('display','block');
            }
            if(ClassConfInit.data.conf.sign_draw){
                if(ClassConfInit.data.Arr_init.length!=0){
                    console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+"cache to paint when canvas ready");
                    comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+"cache to paint when canvas ready");
                    console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+"cache : ");
                    comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+"cache : ");
                    var tem=null;
                    for(var i= 0,j=ClassConfInit.data.Arr_init.length;i<j;i++){
                        var a=ClassConfInit.data.Arr_init.shift();
                        console.log('        ['+constants.timer.toLocaleTimeString()+']'+'----->'+JSON.stringify(a));
                        comm_send.HBlog('        ['+constants.timer.toLocaleTimeString()+']'+'----->'+JSON.stringify(a));
                        if(a.type!='scroll'){
                            comm_type_get(a.type,a.str_obj);
                        }else{
                            tem=a;
                        }
                    }
                    if(tem!=null){
                        comm_type_get(tem.type,tem.str_obj);
                    }
                }
            }
        }
    }
    var DataDraw= function (wid,hei,left,top) {
        var tem=CalculateOffset(wid,hei,ClassConfInit.data.classtype);
        ClassConfInit.data.course.width=wid;
        ClassConfInit.data.course.height=hei;
        ClassConfInit.data.canvas.width=tem.width;
        ClassConfInit.data.canvas.height=tem.height;
        wid=(wid<= $('#showDomain').width()?$('#showDomain').width():wid);
        hei=(hei<= $('#showDomain').height()?$('#showDomain').height():hei);

        $('#showDomain').css({
            'width': wid,
            'height': hei
        });
        $('#paint_board').css({
            'width':tem.width,
            'height':tem.height,
            'top':top+tem.marginY,
            'left':left+tem.marginX+($('#workSpace').width()-wid)/2,
        });
        WEBTools.review();
    }
    var DataPage= function (num) {

    }
    var EventPage= function (num) {
        parentCon.handle.page(num);//初始化页数
        if(ClassConfInit.data.name_login=='tea'){
            var obj={
                'TotalPage':ClassConfInit.data.page.count,
                'CurrentPage':ClassConfInit.data.page.curpageNum-1
            }
            comm_send.UpdatePage(JSON.stringify(obj));
        }

    }
    var removescroll= function (wid) {
        $('#showDomain').width(wid);

        $('#showDomain').css('left', function () {
            return ($('#workSpace').width()-wid)/2;
        });
        commParIf.setresize();
    }
    var resetchild= function () {
        $('#showDomain').css('left',0);
        parentCon.resetscroll=true;
    }
    return{
        'init': function (s) {
            init(s);
        },
        'seturl': function () {
            return ClassConfInit.data.url;
        },
        'setpageEvent': function (num) {
            EventPage(num);
        },
        'getdatadraw': function (wid,hei,left,top) {
            DataDraw(wid,hei,left,top);
        },
        'getdatapage': function () {
            DataPage();
        },
        'setresize': function () {
            parentCon.handle.resize();
        },
        'setscroll': function (wid) {
            removescroll(wid);
        },
        'resetchild': function () {
            resetchild();
        },
        'log': function (str) {
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened : '+str);
        }
    }
})();

var CalculateOffset=function (cx, cy, emType)
{
    var x=0,y=0;
    var temX=cx,temY=cy;
    switch(emType)
    {
        case 0:
            break;
        case 1:
            temX = cx * 732 / 1000;
            temY = temX / 2;
            x = cx * 265 / 1003;
            y = cy * 117 / 503;
            break;
        case 2:
            temX = cx * 268768 / 367500;
            temY = temX * 153853 / 268768;
            x = cx * 870 / 3675;
            y = cy * 49244 / 210000;
            break;
        default:
            break;
    }

    return {marginX:parseInt(x),marginY:parseInt(y),width:parseInt(temX),height:parseInt(temY)};
}

var scroll_tea=function(){
    $('.scroll_tea').css('display','block');
    constants.Arr_scroll.push('Speak slowly to low-leveled students.');
    constants.Arr_scroll.push('Motivate students to speak complete sentences.');
    constants.Arr_scroll.push('Ask students to repeat new words and sentences 2 times.');
    constants.Arr_scroll.push('Correct only those mistakes that lead to misunderstanding.');
    constants.Arr_scroll.push('Don’t stay at warm-up too long, and there must be a wrap-up');
    $('.scroll_tea').text(constants.Arr_scroll.shift());
    setInterval(function () {
        if(constants.Arr_scroll.length==0){
            constants.Arr_scroll.push('Speak slowly to low-leveled students.');
            constants.Arr_scroll.push('Motivate students to speak complete sentences.');
            constants.Arr_scroll.push('Ask students to repeat new words and sentences 2 times.');
            constants.Arr_scroll.push('Correct only those mistakes that lead to misunderstanding.');
            constants.Arr_scroll.push('Don’t stay at warm-up too long, and there must be a wrap-up');
            $('.scroll_tea').text(constants.Arr_scroll.shift());
        }else{
            $('.scroll_tea').text(constants.Arr_scroll.shift());
        }
    },5000)
}

var scroll_wheel=function(){//滚动条
    var topScroll=$('#scrollbar1').find('.thumb')[0].offsetTop,
        heightBar=$('#scrollbar1').find('.thumb')[0].offsetHeight,
        heightScroll=$('#scrollbar1').find('.track')[0].offsetHeight;
    var totalHeight=heightScroll+heightScroll-heightBar;
    var s2=(ClassConfInit.data.course.height-heightScroll)/(heightScroll-heightBar);
    if(heightBar!=0){
        if(ClassConfInit.data.topScroll_changed!=topScroll){
            var obj={
                'totalHeight':parseInt(ClassConfInit.data.course.height),
                'scrollTop':parseInt(topScroll*s2),
                'CurrentPage':ClassConfInit.data.page.curpageNum-1
            };
            comm_send.UpdateScroll(JSON.stringify(obj));
            WEBTools.canvasTop = $("#paint_board").offset().top;
            WEBTools.canvasLeft = $("#paint_board").offset().left;
        }
    }
    ClassConfInit.data.topScroll_changed=topScroll;
}

var titleTip= function () {
    var len=$('#tool_bar_center').find('div').length;
    var arr_title_en=['move','pencil','highlighter','square','write','rubber','draft','back','clear','magic'];
    var tipWordsC='New functions in AC,try after upgrading it!Tips: Click on "Upgrade" in the MENU at  the AC main page.';

    if(ClassConfInit.data.conf.sign_tools){
        for(;len>0;len--){
            $('#tool_bar_center').find('div')[len-1].title=arr_title_en.pop();
        }
    }
    if(ClassConfInit.data.conf.sigh_contain){
        $('#update_cue').find('.cue_base').html(tipWordsC);
        $('#update_cue').find('.cue_update').html('upgrade now');
        $('#update_cue').find('.cue_stop').html('Don\'t ask me again');
    }

}

var throttle= function (method,context) {
    //避免重复操作
    clearTimeout(method.tid);
    method.tid=setTimeout(function () {
        method.call(context);
    },100);
}

var checkCef= function (Arr,process,context) {
    //函数节流
    setTimeout(function () {
        var tem=Arr.shift();
        process.call(context,tem);
        if(Arr.length>0){
            setTimeout(arguments.callee,50);
        }
    },50)
}




















