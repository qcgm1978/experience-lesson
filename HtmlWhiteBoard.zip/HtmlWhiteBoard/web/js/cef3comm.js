var comm_route=(function () {
    var comm_ConfLessonData_get=function(obj){
        console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_ClassData: '+JSON.stringify(obj));
        comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_ClassData: '+JSON.stringify(obj));
        ClassConfInit.route(obj,0);
    }

    var comm_ConfUserData_get=function(obj){
        console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_UserData: '+JSON.stringify(obj));
        comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_UserData: '+JSON.stringify(obj));
        ClassConfInit.route(obj,1);
    }

    var comm_ConfHostData_get=function(obj){
        console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_HostData: '+JSON.stringify(obj));
        comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_HostData: '+JSON.stringify(obj));
        ClassConfInit.route(obj,2);
    }

    var comm_ConfURLData_get=function(obj){
        obj.url=Base64.decode(obj.url);
        console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_URLData: '+JSON.stringify(obj));
        comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'obj_URLData: '+JSON.stringify(obj));
        ClassConfInit.route(obj,3);
    }

    return{
        'ConfLessonData': function (obj) {
            comm_ConfLessonData_get(obj);
        },
        'ConfUserData': function (obj) {
            comm_ConfUserData_get(obj);
        },
        'ConfHostData': function (obj) {
            comm_ConfHostData_get(obj);
        },
        'ConfURLData': function (obj) {
            comm_ConfURLData_get(obj);
        }
    }
})();

var comm_send=(function () {
    var comm_UpdateMouse_send=function(){
        //同步鼠标
        if(WEBTools.moveX!=ClassConfInit.data.mouse.x||WEBTools.moveY!=ClassConfInit.data.mouse.y){//有效的移动
            var obj={
                'canvasWidth':ClassConfInit.data.canvas.width,
                'canvasHeight':ClassConfInit.data.canvas.height,
                'mouseX':Math.round(WEBTools.moveX-$("#paint_board").offset().left),
                'mouseY':Math.round(WEBTools.moveY-$("#paint_board").offset().top),
                'CurrentPage':ClassConfInit.data.page.curpageNum-1
            }
            comm_type_send_set('mouse',JSON.stringify(obj));
            ClassConfInit.data.mouse.x=WEBTools.moveX;
            ClassConfInit.data.mouse.y=WEBTools.moveY;
        }
    }
    var comm_UpdateScroll_send=function(str_obj){
        comm_type_send_set('scroll',str_obj);
    }
    var comm_UpdatePage_send=function(str_obj){
        return comm_type_send_set('page',str_obj);
    }
    var comm_UpdatePaintData_send=function(str_obj){
        return comm_type_send_set('paint',str_obj);
    }
    var comm_HBlog_send=function(str_obj){
        return comm_type_send_set('log',str_obj);
    }
    var comm_UpdateAC_send= function () {
        return comm_type_send_set('update','');
    }
    var comm_MagicImage_send= function (str_obj) {
        return comm_type_send_set('magic',str_obj);
    }
    var comm_UpdateYoungPage_send= function (cur,count) {
        var obj={
            'cur':cur,
            'count':count
        };
        return comm_type_send_set('teenpage',JSON.stringify(obj));
    }
    var comm_UpdatePptData_send= function (str_obj) {
        return comm_type_send_set('paint',str_obj);
    }
    return{
        'UpdateMouse': comm_UpdateMouse_send,
        'UpdateScroll': function (str_obj) {
            comm_UpdateScroll_send(str_obj);
        },
        'UpdatePage': function (str_obj) {
            comm_UpdatePage_send(str_obj);
        },
        'UpdatePaintData': function (str_obj) {
            comm_UpdatePaintData_send(str_obj);
        },
        'HBlog': function (str_obj) {
            comm_HBlog_send(str_obj);
        },
        'UpdateAC': comm_UpdateAC_send,
        'MagicImage': function (str_obj) {
            comm_MagicImage_send(str_obj);
        },
        'UpdateYoungPage': function (cur,count) {
            comm_UpdateYoungPage_send(cur,count);
        },
        'UpdatePptData':function(str_obj){
            comm_UpdatePptData_send(str_obj);
        }
    }
})();

var comm_get=(function () {
    var comm_UpdateMouse_get=function(obj){
        try{
            if(ClassConfInit.data.page.curpageNum==ClassConfInit.data.tea.pageNum){
                var s=ClassConfInit.data.canvas.width/obj.canvasWidth;
                $('#mouseTea').animate({
                    'left': obj.mouseX*s,
                    'top' :obj.mouseY*s
                },'fast')
            }
        }catch(e){
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Mouse update: '+e);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Mouse update: '+e);
        }
    }
    var comm_UpdateScroll_get=function(obj){
        try{
            var topScroll=$('#scrollbar1').find('.thumb')[0].offsetTop,
                heightBar=$('#scrollbar1').find('.thumb').height(),
                heightScroll=$('#scrollbar1').find('.track')[0].offsetHeight;
            var totalHeight=heightScroll+heightScroll-heightBar;
            if(heightScroll!=0&&ClassConfInit.data.page.curpageNum==ClassConfInit.data.tea.pageNum&&ClassConfInit.data.name_login!='tea'){
                var s0=ClassConfInit.data.course.height/obj.totalHeight;
                var newTop=obj.scrollTop*s0;
                var s1=(heightScroll-heightBar)/(ClassConfInit.data.course.height-heightScroll);
                if(newTop>(ClassConfInit.data.course.height-$('#overview').height())){
                    newTop=ClassConfInit.data.course.height-$('#overview').height();
                }
                $('#scrollbar1').find('.thumb').animate({'top':newTop*s1},'fast');

                $('#overview').animate({'top':newTop*-1},'fast');
            }
        }catch(e){
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Scroll update : '+e);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Scroll update(cef3comm.js  68) : '+e);
        }

    }
    var comm_UpdatePage_get=function(obj){
        try{
            ClassConfInit.data.tea.pageNum=obj.CurrentPage+1;

            if(ClassConfInit.data.courseyoung){
                comm_send.UpdateYoungPage(obj.CurrentPage+1,ClassConfInit.data.page.count);
            }

            if(obj.CurrentPage+1!=ClassConfInit.data.page.curpageNum){//判断当前页是否和老师端的页码相同
                ClassConfInit.data.page.curpageNum=obj.CurrentPage+1;
                if(ClassConfInit.data.conf.sign_page) {//如果存在这个模块
                    $('#pageNumber').val(ClassConfInit.data.page.curpageNum);
                    $('#update_tea').css('display','none');
                }
                if(ClassConfInit.data.conf.sign_draw){
                    if(ClassConfInit.data.candraw){
                        tools.init();
                        tools.css_reInit(tools.sign_tool_state);
                        WEBTools.draw(WEBTools.last_handle);
                    }
                }
                //commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
                var num=parseInt(ClassConfInit.data.page.curpageNum)-1;
                if(num<10){
                    num='0'+num;
                }
                $('#showDomain').attr('src','./src/ppt/'+num+'/index.html');
                WEBTools.repaint();
            }
            if(obj.TotalPage!=ClassConfInit.data.page.count){
                console.log('different count pageNumber');
                comm_send.HBlog('different count pageNumber');
            }
        }catch(e){
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Page update : '+e);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Page update (cef3comm.js  92): '+e);
        }

    }
    var comm_UpdateYoungPage_get= function (obj) {
        //青少教室
        switch (obj.type){
            case 'up':
                if(ClassConfInit.data.page.curpageNum>1){
                    ClassConfInit.data.page.curpageNum=parseInt(ClassConfInit.data.page.curpageNum)-1;
                    next_previous();
                    commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
                }
                break;
            case 'down':
                if(ClassConfInit.data.page.curpageNum<ClassConfInit.data.page.count){
                    ClassConfInit.data.page.curpageNum=parseInt(ClassConfInit.data.page.curpageNum)+1;
                    next_previous();
                    commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
                }
                break;
            case 'skip':
                var num=parseInt(obj.num);

                if(num>=1&&num<=ClassConfInit.data.page.count){
                    ClassConfInit.data.page.curpageNum=num;
                    next_previous();
                    commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
                }
                break;
            case 'synchro':
                var temdata=ClassConfInit.data;
                temdata.page.curpageNum=parseInt(temdata.tea.pageNum);
                next_previous();
                commParIf.setpageEvent(temdata.tea.pageNum);
                break;
            default :
                break;
        }
        comm_send.UpdateYoungPage(ClassConfInit.data.page.curpageNum,ClassConfInit.data.page.count);
    }
    var comm_UpdatePaintData_get=function(obj){
        try{
            if(obj.handleType==0){
                if([0,2,3,4,10,500].indexOf(obj.drawingType)!=-1){
                    if(obj.drawingType!=500){
                        var e=new paint(obj);
                        e.init_paint(obj);
                        e.handle(WEBTools.context);
                    }else
                    {
                        switch (obj.specialValue.type){
                            case 0://新版橡皮擦
                                var e=search(obj.specialValue.id);
                                if(e!=null){
                                    e.init_paint(obj);
                                    WEBTools.repaint();
                                }else{
                                    comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when new rubber: error id to draft');
                                }
                                break;
                            case 1://拖动
                                var e=search(obj.specialValue.id);
                                if(e!=null){
                                    e.init_paint(obj);
                                    WEBTools.repaint();
                                }else{
                                    comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when draft handle: error id to draft');
                                }
                                break;
                            case 2://重写
                                var e=search(obj.specialValue.id);
                                if(e!=null){
                                    e.init_paint(obj);
                                    WEBTools.repaint();
                                }else{
                                    comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when reedit handle: error id to reedit');
                                }
                                break;
                            case 10://ppt
                                commData_set('data',JSON.stringify(obj.specialValue.value));
                                break;
                            case 11://开始上课，老师进入教室
                                var num=parseInt(ClassConfInit.data.tea.pageNum-1);
                                if(num<10){
                                    num='0'+num;
                                }
                                $('#showDomain').attr('src','./src/ppt/'+num+'/index.html');
                                $('.toolContain').css('display','none');
                                commData_set('update',JSON.stringify(obj.specialValue.value));
                                curState=﻿obj.specialValue.value.value.curState
                                break;
                            case 12://模块内翻页
                                commData_set('resetHref',obj.specialValue.value);
                                break;
                            default :
                                if(ClassConfInit.data.tip_update){
                                    WEBTools.order_list.push(-2);//未知修改操作（未来可能添加）
                                    WEBTools.svcId++;
                                    $('#update_cue').css('display','block');
                                }
                                break;
                        }
                    }
                }else if(ClassConfInit.data.tip_update){
                    WEBTools.order_list.push(-3);
                    WEBTools.svcId++;
                    $('#update_cue').css('display','block');
                }
            }else if(obj.handleType==1){
                if(obj.drawingType==1)
                    WEBTools.draw('back',1);
                else if(obj.drawingType==2)
                    WEBTools.draw('clear',1);
                else if(ClassConfInit.data.tip_update){
                    $('#update_cue').css('display','block');
                }
            }else if(obj.handleType==2){
                if(ClassConfInit.data.tip_update){
                    $('#update_cue').css('display','block');
                }
            }else {
                if(ClassConfInit.data.tip_update){
                    $('#update_cue').css('display','block');
                }
            }
        }catch(e){
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Paint update (cef3comm.js  126): '+e);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when Paint update(cef3comm.js  126) : '+e);
        }
        function search(id){
            var i,j;
            for(i= 0,j=WEBTools.pDone_Arr.length;i<j;i++){
                if(WEBTools.pDone_Arr[i].id==id&&WEBTools.pDone_Arr[i].changeCount!=0){
                    return WEBTools.pDone_Arr[i];
                }
            }
            return null;
        }
    }
    var comm_UpdateYoungTools_get= function (obj) {
        if(ClassConfInit.data.tea.login){
            switch (obj.type){
                case 'pen':
                    WEBTools.draw('pencil');
                    break;
                case 'signpen':
                    WEBTools.draw('sign_pencil');
                    break;
                case 'rec':
                    WEBTools.draw('square');
                    break;
                case 'rub':
                    WEBTools.draw('rubber');
                    break;
                case 'newrub':
                    WEBTools.draw('newrub');
                    break;
                case 'text':
                    if(obj.size=='small'){
                        ClassConfInit.data.font.fontSize=16;
                    }else{
                        ClassConfInit.data.font.fontSize=25;
                    }
                    WEBTools.draw('write',false);
                    break;
                case 'draft':
                    WEBTools.draw('draft');
                    break;
                case 'back':
                    WEBTools.draw('back');
                    break;
                case 'clear':
                    WEBTools.draw('clear');
                    break;
                default :
                    console.error('wrong type : '+obj.type);
                    break;
            }
        }
    }
    var comm_UpdatePageClick_get= function (obj) {
        try{
            if(tools.tool_e){
                tools.tool_e.tool_skip(obj.targetPage);
            }
        }catch(e){
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error when click pageChange :'+ e);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error when click pageChange :'+ e);
        }
    }
    return{
        'UpdateMouse': function (obj) {
            comm_UpdateMouse_get(obj);
        },
        'UpdateScroll': function (obj) {
            comm_UpdateScroll_get(obj);
        },
        'UpdatePage': function (obj,s) {
            comm_UpdatePage_get(obj,s);
        },
        'UpdatePaintData': function (obj) {
            comm_UpdatePaintData_get(obj);
        },
        'UpdateYoungTools': function (obj) {
            comm_UpdateYoungTools_get(obj);
        },
        'UpdateYoungPage': function (obj) {
            comm_UpdateYoungPage_get(obj);
        },
        'UpdatePageClick': function (obj) {
            comm_UpdatePageClick_get(obj);
        }
    }
})();

var comm_type_send_set= function (type,str_obj) {
    var tem_e={
        'type':type,
        'str':str_obj
    };
    if(ClassConfInit.data.timeArr.length>0){
        ClassConfInit.data.timeArr.push(tem_e);
    }else{
        ClassConfInit.data.timeArr.push(tem_e);
        checkCef(ClassConfInit.data.timeArr,comm_type_send);
    }
}

//实现通信的代理
var comm_type_send=function(tem_e){
    if(ClassConfInit.data.HostType=='cef3'){//cef3通信方式
        var a=null;
        try{
            a=window.AcJs_get(tem_e.type,tem_e.str);
        }catch(e){
            a=null;
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'failed to send data to cef3 (cef3comm.js  138) :'+ e);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'failed to send data to cef3 (cef3comm.js  138) :'+ e);
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'type: '+type+'  str_obj:'+tem_e.str);
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'type: '+type+'  str_obj:'+tem_e.str);
        }
        return a;
    }
    else
    {
        return 0;
    }
}

var comm_type_get=function(type,str_obj){
    if(type=='course'){
        comm_route.ConfLessonData(JSON.parse(str_obj));
    }else if(type=='user'){
        comm_route.ConfUserData(JSON.parse(str_obj));
    }
    else if(type=='host'){
        comm_route.ConfHostData(JSON.parse(str_obj));
    }
    else if(type=='url'){
        comm_route.ConfURLData(JSON.parse(str_obj));
    }
    else
    {
        var tem_json={
            'type':type,
            'str_obj':str_obj
        };
        if(!ClassConfInit.data.completeCourse){
            console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'canvas is not ready , push data to Array : '+JSON.stringify(tem_json));
            comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'canvas is not ready , push data to Array : '+JSON.stringify(tem_json));
            ClassConfInit.data.Arr_init.push(tem_json);
        }else{
            try{
                if(ClassConfInit.data.HostType=='cef3'){//cef3通信方式
                    switch (tem_json.type){
                        case 'mouse':
                            comm_get.UpdateMouse(JSON.parse(tem_json.str_obj));
                            break;
                        case 'scroll':
                            comm_get.UpdateScroll(JSON.parse(tem_json.str_obj));
                            break;
                        case 'page':
                            comm_get.UpdatePage(JSON.parse(tem_json.str_obj));
                            break;
                        case 'pageclick':
                            comm_get.UpdatePageClick(JSON.parse(tem_json.str_obj));
                            break;
                        case 'gopage'://青少教室
                            comm_get.UpdateYoungPage(JSON.parse(tem_json.str_obj));
                            break;
                        case 'paint':
                            var tem=JSON.parse(tem_json.str_obj);
                            comm_get.UpdatePaintData(tem);
                            break;
                        case 'enterout':
                            if(ClassConfInit.data.tea.login&&JSON.parse(tem_json.str_obj).Bl_E_O==0){
                                //老师已经登陆，接收到老师退出的消息
                                console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'teacher out class');
                                comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'teacher out class');
                                ClassConfInit.data.tea.login=false;
                                if(ClassConfInit.data.conf.sign_tools){//如果存在这个模块
                                    $('#outerCenter').css('display','none');
                                }
                                if(ClassConfInit.data.conf.sign_draw){//老师进出教室要把鼠标样式改变
                                    if(ClassConfInit.data.courseyoung){
                                        $('#canvas_bak').css('cursor','url(images/young_normal.png) 25 15,auto');
                                    }else{
                                        $('#canvas_bak').css('cursor','url(images/normal.png) 0 0,auto');
                                    }
                                }
                                /*ppt__________________________________________________________________________________________start*/
                                var pptObj={
                                    type:'classIO',
                                    value:{
                                        curState:'out'
                                    }
                                };
                                commData_set('update',JSON.stringify(pptObj));
                                /*ppt__________________________________________________________________________________________end*/
                            }else if(!ClassConfInit.data.tea.login&&JSON.parse(tem_json.str_obj).Bl_E_O==1){
                                //老师已经退出，接收到老师登陆的消息
                                console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'teacher enter class');
                                comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'teacher enter class');
                                ClassConfInit.data.tea.login=true;
                                if(ClassConfInit.data.conf.sign_tools){//如果存在这个模块
                                    tools.css_reInit(tools.sign_tool_state);
                                }
                                if(ClassConfInit.data.conf.sign_draw&&ClassConfInit.data.candraw){//老师进出教室要把鼠标样式改变
                                    WEBTools.draw(WEBTools.last_handle);
                                }
                                /*ppt__________________________________________________________________________________________start*/
                                var pptObj={
                                    type:'classIO',
                                    value:{
                                        curState:'in'
                                    }
                                };
                                commData_set('update',JSON.stringify(pptObj));
                                /*ppt__________________________________________________________________________________________end*/
                            }
                            break;
                        case 'tools':
                            comm_get.UpdateYoungTools(JSON.parse(tem_json.str_obj));
                            break;
                        default :
                            if(ClassConfInit.data.tip_update){
                                $('#update_cue').css('display','block');
                            }
                            break;
                    }
                }
            }catch(e){
                console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when get data from cef3(cef3comm.js  234) : '+e);
                comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when get data from cef3(cef3comm.js  234) : '+e);
            }
        }
    }
    return null;
}

var Base64 = {
    // 转码表
    table : [
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
        'I', 'J', 'K', 'L', 'M', 'N', 'O' ,'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
        'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3',
        '4', '5', '6', '7', '8', '9', '+', '/'
    ],
    UTF16ToUTF8 : function(str) {
        var res = [], len = str.length;
        for (var i = 0; i < len; i++) {
            var code = str.charCodeAt(i);
            if (code > 0x0000 && code <= 0x007F) {
                // 单字节，这里并不考虑0x0000，因为它是空字节
                // U+00000000 – U+0000007F  0xxxxxxx
                res.push(str.charAt(i));
            } else if (code >= 0x0080 && code <= 0x07FF) {
                // 双字节
                // U+00000080 – U+000007FF  110xxxxx 10xxxxxx
                // 110xxxxx
                var byte1 = 0xC0 | ((code >> 6) & 0x1F);
                // 10xxxxxx
                var byte2 = 0x80 | (code & 0x3F);
                res.push(
                    String.fromCharCode(byte1),
                    String.fromCharCode(byte2)
                );
            } else if (code >= 0x0800 && code <= 0xFFFF) {
                // 三字节
                // U+00000800 – U+0000FFFF  1110xxxx 10xxxxxx 10xxxxxx
                // 1110xxxx
                var byte1 = 0xE0 | ((code >> 12) & 0x0F);
                // 10xxxxxx
                var byte2 = 0x80 | ((code >> 6) & 0x3F);
                // 10xxxxxx
                var byte3 = 0x80 | (code & 0x3F);
                res.push(
                    String.fromCharCode(byte1),
                    String.fromCharCode(byte2),
                    String.fromCharCode(byte3)
                );
            } else if (code >= 0x00010000 && code <= 0x001FFFFF) {
                // 四字节
                // U+00010000 – U+001FFFFF  11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
            } else if (code >= 0x00200000 && code <= 0x03FFFFFF) {
                // 五字节
                // U+00200000 – U+03FFFFFF  111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
            } else /** if (code >= 0x04000000 && code <= 0x7FFFFFFF)*/ {
                // 六字节
                // U+04000000 – U+7FFFFFFF  1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
            }
        }

        return res.join('');
    },
    UTF8ToUTF16 : function(str) {
        var res = [], len = str.length;
        var i = 0;
        for (var i = 0; i < len; i++) {
            var code = str.charCodeAt(i);
            // 对第一个字节进行判断
            if (((code >> 7) & 0xFF) == 0x0) {
                // 单字节
                // 0xxxxxxx
                res.push(str.charAt(i));
            } else if (((code >> 5) & 0xFF) == 0x6) {
                // 双字节
                // 110xxxxx 10xxxxxx
                var code2 = str.charCodeAt(++i);
                var byte1 = (code & 0x1F) << 6;
                var byte2 = code2 & 0x3F;
                var utf16 = byte1 | byte2;
                res.push(
                    String.fromCharCode(utf16)
                );
            } else if (((code >> 4) & 0xFF) == 0xE) {
                // 三字节
                // 1110xxxx 10xxxxxx 10xxxxxx
                var code2 = str.charCodeAt(++i);
                var code3 = str.charCodeAt(++i);
                var byte1 = (code << 4) | ((code2 >> 2) & 0x0F);
                var byte2 = ((code2 & 0x03) << 6) | (code3 & 0x3F);
                utf16 = ((byte1 & 0x00FF) << 8) | byte2
                res.push(String.fromCharCode(utf16));
            } else if (((code >> 3) & 0xFF) == 0x1E) {
                // 四字节
                // 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
            } else if (((code >> 2) & 0xFF) == 0x3E) {
                // 五字节
                // 111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
            } else /** if (((code >> 1) & 0xFF) == 0x7E)*/ {
                // 六字节
                // 1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
            }
        }

        return res.join('');
    },
    encode : function(str) {
        if (!str) {
            return '';
        }
        var utf8    = this.UTF16ToUTF8(str); // 转成UTF8
        var i = 0; // 遍历索引
        var len = utf8.length;
        var res = [];
        while (i < len) {
            var c1 = utf8.charCodeAt(i++) & 0xFF;
            res.push(this.table[c1 >> 2]);
            // 需要补2个=
            if (i == len) {
                res.push(this.table[(c1 & 0x3) << 4]);
                res.push('==');
                break;
            }
            var c2 = utf8.charCodeAt(i++);
            // 需要补1个=
            if (i == len) {
                res.push(this.table[((c1 & 0x3) << 4) | ((c2 >> 4) & 0x0F)]);
                res.push(this.table[(c2 & 0x0F) << 2]);
                res.push('=');
                break;
            }
            var c3 = utf8.charCodeAt(i++);
            res.push(this.table[((c1 & 0x3) << 4) | ((c2 >> 4) & 0x0F)]);
            res.push(this.table[((c2 & 0x0F) << 2) | ((c3 & 0xC0) >> 6)]);
            res.push(this.table[c3 & 0x3F]);
        }

        return res.join('');
    },
    decode : function(str) {
        if (!str) {
            return '';
        }

        var len = str.length;
        var i   = 0;
        var res = [];

        while (i < len) {
            code1 = this.table.indexOf(str.charAt(i++));
            code2 = this.table.indexOf(str.charAt(i++));
            code3 = this.table.indexOf(str.charAt(i++));
            code4 = this.table.indexOf(str.charAt(i++));

            c1 = (code1 << 2) | (code2 >> 4);
            c2 = ((code2 & 0xF) << 4) | (code3 >> 2);
            c3 = ((code3 & 0x3) << 6) | code4;

            res.push(String.fromCharCode(c1));

            if (code3 != 64) {
                res.push(String.fromCharCode(c2));
            }
            if (code4 != 64) {
                res.push(String.fromCharCode(c3));
            }

        }

        return this.UTF8ToUTF16(res.join(''));
    }
};