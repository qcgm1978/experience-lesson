﻿/**
 * Created by Administrator on 2015/12/11.
 */
var WEBTools={
    pDone_Arr:[],//存储所有笔迹
    order_list:[],//存储所有操作顺序

    svcId:1,//代表服务器所需id

    canvas:null,
    canvas_bak:null,
    context:null,
    context_bak:null,
    //记录canvas距离浏览器的边距
    canvasTop:0,
    canvasLeft:0,
    canvasWidth:0,
    canvasHeight:0,

    //实现文字输入
    input:null,
    edit:null,
    PaintBoard:null,//画板父类窗口
    span_wid:null,//用于定位文字打印时换行位置
    //用来记录上一个笔触类型，也是默认第一笔为画笔
    last_handle:'pencil',
    graphType:'',//用于记录当前的笔触类型

    //在鼠标移动的时候记录所有的点坐标
    arr_canvas_temp:[],
    //用于组成对象
    arr_handleData:[],

    //防止没有点击操作时的move事件执行
    canDraw:false,

    //分别记录鼠标点击时的距离canvas左上角的坐标点
    startX:0,
    startY:0,

    moveX:0,//用于鼠标同步
    moveY:0,//用于鼠标同步

    //这里是关于write的参数
    sign_write:false,//代表是否处于已经在输入文字的状态
    x_write:0,//文字输入框左上角位置
    y_write:0,//文字输入框左上角位置
    sign_reedite:false,//是否处于重写模式

    //实现拖动 记录拖动时点击的div的位置
    x_div_click:0,
    y_div_click:0,

    x_min:0,//用来记录x的最小值
    x_max:0,//用来记录x的最大值
    y_min:0,//用来记录y的最小值
    y_max:0,//用来记录y的最大值

    text_temp:"",//用来记录输入，以便在高度超出时禁止输入

    target_e:null, //记录目标对象
    target_e_left:0,//记录目标对象的初始左偏移
    target_e_top:0,//记录目标对象的初始右偏移

    //表示鼠标移动时上一步是否有颜色变化
    move_repaint:false,
    last_handle_id:0,//鼠标移动中记录上一个目标对象的id

    mouse_move:false,//用来防止鼠标抬起up事件未触发状况

    init:function (){
        $('#scrollbar1').tinyscrollbar();
        WEBTools.canvas=document.getElementById("canvas");
        WEBTools.canvas_bak=document.getElementById("canvas_bak");
        WEBTools.context=WEBTools.canvas.getContext('2d');
        WEBTools.context_bak = WEBTools.canvas_bak.getContext('2d');
        WEBTools.input=document.getElementById("input");
        WEBTools.edit=document.getElementById('edit');
        WEBTools.PaintBoard=document.getElementById('paint_board');
        WEBTools.span_wid=document.getElementById("span_wid");
        WEBTools.span_wid.style.zIndex=-1;
        WEBTools.review();
        document.title='Html_White_Board';

        if(ClassConfInit.data.conf.sign_draw&&ClassConfInit.data.courseyoung){//修改默认样式
            $('#canvas_bak').css('cursor','url(images/young_normal.png) 25 15,auto');
            $('#mouseTea').css({
                'width': '64px',
                'height': '64px',
                'background-image':'url("images/young_mouse_tea.png")'
            });
            $('#input').css('cursor','url(images/young_move.png) 15 4,auto');
        }

        if(ClassConfInit.data.candraw){
            WEBTools.edit.onkeyup= function () {
                WEBTools.key_event(WEBTools.edit);
            }

            WEBTools.edit.onkeydown= function () {
                WEBTools.key_event(WEBTools.edit);
            }

            WEBTools.edit.onfocus= function () {
                WEBTools.sign_write=false;
            }
            //为画布添加双击事件
            WEBTools.canvas_bak.ondblclick= function (e) {
                if(ClassConfInit.data.versionType=='new')
                    WEBTools.DBClick(e);
            }
            if(ClassConfInit.data.tea.login){
                WEBTools.draw(WEBTools.last_handle);
            }else{
                if(ClassConfInit.data.courseyoung){//修改默认样式
                    $('#canvas_bak').css('cursor','url(images/young_normal.png) 25 15,auto');
                }
            }
        }
    },

    review: function () {
        $('#scrollbar1').tinyscrollbar_update();
        //WEBTools.canvasWidth=ClassConfInit.data.canvas.width;
        //WEBTools.canvasHeight=ClassConfInit.data.canvas.height;

        WEBTools.canvasWidth=1047;
        WEBTools.canvasHeight=598;


        WEBTools.canvasTop = $("#paint_board").offset().top;
        WEBTools.canvasLeft = $("#paint_board").offset().left;
        WEBTools.canvas.width = WEBTools.canvasWidth;
        WEBTools.canvas.height = WEBTools.canvasHeight;
        WEBTools.PaintBoard.style.width=WEBTools.canvasWidth+'px';
        WEBTools.PaintBoard.style.height=WEBTools.canvasHeight+'px';
        WEBTools.canvas_bak.width = WEBTools.canvasWidth;
        WEBTools.canvas_bak.height = WEBTools.canvasHeight;
        
        if(ClassConfInit.data.tea.pageNum==ClassConfInit.data.page.curpageNum){
            WEBTools.repaint();
        }
    },

    draw:function (graphType,s){
        WEBTools.graphType=graphType;
        WEBTools.write_writing();//处理文字编辑时，未点击白板，点击工具栏

        switch (graphType){
            case 'pencil':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_pen.png) 25 10,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/pen.png) 0 24,auto';
                }
                WEBTools.last_handle='pencil';
                WEBTools.bind(WEBTools.canvas_bak);
                break;
            case 'sign_pencil':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_yingguang.png) 0 3,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/yingguang.png) 0 24,auto';
                }

                WEBTools.last_handle='sign_pencil';
                WEBTools.bind(WEBTools.canvas_bak);
                break;
            case 'square':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_juxing.png) 32 32,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/juxing.png) 12 12,auto';
                }

                WEBTools.last_handle='square';
                WEBTools.bind(WEBTools.canvas_bak);
                break;
            case 'rubber':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_erase.png) 32 32,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/delete.png) 12 12,auto';
                }
                WEBTools.last_handle='rubber';

                WEBTools.bind(WEBTools.canvas_bak);
                break;
            case 'newrub':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_erase.png) 32 32,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/delete.png) 12 12,auto';
                }
                WEBTools.last_handle='newrub';

                WEBTools.bind(WEBTools.canvas_bak);
                break;
            case 'write':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_input.png) 32 32,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/type.png) 12 12,auto';
                }

                if(!s){//处理当前非文本笔触时重写
                    WEBTools.last_handle='write';
                }

                WEBTools.bind(WEBTools.canvas_bak);

                WEBTools.bind(WEBTools.input);
                break;
            case 'back':
                /*封装obj*/
                if(WEBTools.order_list.length!=0){
                    var targetId=WEBTools.order_list.pop();
                    if(!s){
                        var obj={
                            'handleType':1,/*代表撤销*/
                            'drawingType':1,
                            'specialValue':null
                        }
                        comm_send.UpdatePaintData(JSON.stringify(obj));
                    }

                    WEBTools.handle_back(targetId);
                }
                if(WEBTools.last_handle!='write'){
                    WEBTools.draw(WEBTools.last_handle);
                }else
                {
                    WEBTools.draw(WEBTools.last_handle,false);
                }
                break;
            case 'clear':
                if(!s){
                    /*封装obj*/
                    var obj={
                        'handleType':1,/*删*/
                        'drawingType':2,/*代表清空*/
                        'specialValue':null
                    }
                    comm_send.UpdatePaintData(JSON.stringify(obj));
                }
                WEBTools.handle_clear();
                break;
            case 'draft':
                if(ClassConfInit.data.courseyoung){
                    WEBTools.canvas_bak.style.cursor='url(images/young_move.png) 15 4,auto';
                }else{
                    WEBTools.canvas_bak.style.cursor='url(images/move.png) 12 12,auto';
                }

                WEBTools.last_handle='draft';
                WEBTools.bind(WEBTools.canvas_bak);
                break;
            default :
                break;
        }
    },

    bind:function (target){
        $(target).unbind();
        $(target).bind('mousedown',WEBTools.mousedown);
        $(target).bind('mousemove',WEBTools.mousemove);
        $(target).bind('mouseup',WEBTools.mouseup);
        $(target).bind('mouseout',WEBTools.mouseout);
        WEBTools.mouse_move=false;
    },

    mousedown:function (e){
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        if(ClassConfInit.data.candraw&&ClassConfInit.data.tea.login&&ClassConfInit.data.page.curpageNum==ClassConfInit.data.tea.pageNum){//老师是否在线是否在同页,公开课以及其他学生不能使用画笔的情况都已经在前面init去除
            WEBTools.canvasTop = $("#paint_board").offset().top;
            WEBTools.canvasLeft = $("#paint_board").offset().left;
            WEBTools.context_bak.strokeStyle= ClassConfInit.data.pencil.color;
            WEBTools.context_bak.lineWidth = ClassConfInit.data.pencil.size*canvasW/800;

            var e=e||window.event||arguments.callee.caller.arguments[0];
            WEBTools.startX = Math.round( e.clientX+document.body.scrollLeft - WEBTools.canvasLeft);
            WEBTools.startY =  Math.round(e.clientY+document.body.scrollTop - WEBTools.canvasTop);
            WEBTools.context_bak.moveTo(WEBTools.startX,WEBTools.startY);

            WEBTools.x_min=WEBTools.startX;
            WEBTools.x_max=WEBTools.startX;
            WEBTools.y_min=WEBTools.startY;
            WEBTools.y_max=WEBTools.startY;

            WEBTools.canDraw = true;

            WEBTools.arr_canvas_temp.length=0;

            if(WEBTools.mouse_move){//防止up事件未触发
                WEBTools.mouseup();
            }

            switch (WEBTools.graphType){
                case 'pencil':
                    WEBTools.arr_canvas_temp.push({'x':WEBTools.startX,'y':WEBTools.startY});
                    WEBTools.context_bak.beginPath();
                    break;
                case 'sign_pencil':
                    WEBTools.arr_canvas_temp.push({'x':WEBTools.startX,'y':WEBTools.startY});
                    WEBTools.context_bak.save();
                    WEBTools.context_bak.beginPath();
                    WEBTools.context_bak.globalAlpha=0.5;
                    WEBTools.context_bak.globalCompositeOperation='xor';
                    WEBTools.context_bak.strokeStyle=ClassConfInit.data.pencil.color_sign;
                    WEBTools.context_bak.lineWidth=20*canvasW/800;
                    break;
                case 'square':
                    WEBTools.arr_canvas_temp.push({'x':WEBTools.startX,'y':WEBTools.startY});
                    break;
                case 'rubber':
                    var sizerub=ClassConfInit.data.pencil.rubbersize;
                    WEBTools.arr_canvas_temp.push({'x':WEBTools.startX,'y':WEBTools.startY});
                    WEBTools.context.clearRect(WEBTools.startX-sizerub/2,WEBTools.startY-sizerub/2,sizerub,sizerub);
                    break;
                case 'newrub':
                    var e=WEBTools.target_e;
                    if(e){
                        WEBTools.e_color_init();
                        e.color=ClassConfInit.data.pencil.color_target;
                        WEBTools.repaint();
                    }
                    break;
                case 'write':
                    $('#Center_chose').css('display','none');
                    var target = e.target || e.srcElement;
                    if(target.id!="input"&&target.id!='edit'&&ClassConfInit.data.tea.pageNum==ClassConfInit.data.page.curpageNum){
                        if(WEBTools.input.style.display=="none")
                        {
                            WEBTools.write_start(WEBTools.startX,WEBTools.startY);
                        }
                        else{
                            WEBTools.write_end();
                            WEBTools.clearConText();
                        }
                    }
                    else if(target.id=="input"){
                        WEBTools.sign_write=true;
                        WEBTools.edit.readOnly='true';
                    }
                    else{
                        WEBTools.sign_write=false;
                        WEBTools.edit.readOnly='';
                    }
                    break;
                case 'draft':
                    if(WEBTools.target_e&&WEBTools.target_e.drawingType!=10){
                        //必须记录的两个重要信息
                        WEBTools.target_e_left=WEBTools.target_e.drag_left;
                        WEBTools.target_e_top=WEBTools.target_e.drag_top;
                        WEBTools.target_e.color=ClassConfInit.data.pencil.color_target;
                        //先隐藏这笔，但是要画在蒙版上
                        WEBTools.target_e.display=0;
                        WEBTools.repaint();
                        WEBTools.target_e.display=1;
                        WEBTools.target_e.handle(WEBTools.context_bak,2);
                    }
                    break;
                default :
                    break;
            }

        }
		window.event.preventDefault();
		window.event.stopPropagation();
	},
    mousemove:function (e){
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        var e=e||window.event||arguments.callee.caller.arguments[0];
        var x =  Math.round(e.clientX+document.body.scrollLeft - WEBTools.canvasLeft);
        var y =  Math.round(e.clientY+document.body.scrollTop - WEBTools.canvasTop);
        WEBTools.moveX= Math.round(e.clientX);
        WEBTools.moveY=  Math.round(e.clientY);

        if(ClassConfInit.data.tea.pageNum==ClassConfInit.data.page.curpageNum&&WEBTools.canDraw){

            WEBTools.x_min=(x<WEBTools.x_min)?x:WEBTools.x_min;
            WEBTools.x_max=(x>WEBTools.x_max)?x:WEBTools.x_max;
            WEBTools.y_min=(y<WEBTools.y_min)?y:WEBTools.y_min;
            WEBTools.y_max=(y>WEBTools.y_max)?y:WEBTools.y_max;

            WEBTools.mouse_move=true;

            switch (WEBTools.graphType){
                case 'pencil':
                    WEBTools.context_bak.lineTo(x ,y);
                    WEBTools.context_bak.stroke();
                    WEBTools.arr_canvas_temp.push({'x':x,'y':y});
                    break;
                case 'sign_pencil':
                    WEBTools.context_bak.lineTo(x ,y);
                    WEBTools.context_bak.stroke();
                    WEBTools.arr_canvas_temp.push({'x':x,'y':y});
                    //canvas_circle(WEBTools.context_bak,x,y);
                    break;
                case 'square'://方块  4条直线
                    WEBTools.context_bak.beginPath();
                    WEBTools.clearConText();
                    WEBTools.context_bak.moveTo(WEBTools.startX , WEBTools.startY);
                    WEBTools.context_bak.lineTo(x  ,WEBTools.startY );
                    WEBTools.context_bak.lineTo(x  ,y );
                    WEBTools.context_bak.lineTo(WEBTools.startX  ,y );
                    WEBTools.context_bak.lineTo(WEBTools.startX  ,WEBTools.startY );
                    WEBTools.context_bak.lineTo(x  ,WEBTools.startY );
                    WEBTools.context_bak.stroke();
                    break;
                case 'rubber'://橡皮擦 不管有没有在画都出现小方块 按下鼠标 开始清空区域
                    var sizerub=ClassConfInit.data.pencil.rubbersize;
                    WEBTools.arr_canvas_temp.push({'x':x,'y':y});
                    WEBTools.context.clearRect(x-sizerub/2,y-sizerub/2,sizerub,sizerub);
                    break;
                case 'newrub':
                    WEBTools.target_e=WEBTools.e_search(x,y);
                    var e=WEBTools.target_e;
                    if(e){
                        WEBTools.e_color_init();
                        e.color=ClassConfInit.data.pencil.color_target;
                        WEBTools.repaint();
                    }
                    else{
                        WEBTools.e_color_init();
                        WEBTools.repaint();
                    }
                    break;
                case 'write':
                    if(WEBTools.sign_write)
                    {
                        WEBTools.input.style.left=WEBTools.x_div_click+x-WEBTools.startX+'px';
                        WEBTools.input.style.top=WEBTools.y_div_click+y-WEBTools.startY+'px';
                        WEBTools.x_write=WEBTools.x_div_click+x-WEBTools.startX;
                        WEBTools.y_write=WEBTools.y_div_click+y-WEBTools.startY;
                    }
                    break;
                case 'draft':
                    //这里做移动操作
                    if(WEBTools.target_e){
                        WEBTools.clearConText();
                        var s=WEBTools.target_e.canvasWidth/canvasW;
                        WEBTools.target_e.drag_left= Math.round((x-WEBTools.startX)*s+WEBTools.target_e_left);
                        WEBTools.target_e.drag_top= Math.round((y-WEBTools.startY)*s+WEBTools.target_e_top);

                        WEBTools.target_e.handle(WEBTools.context_bak,2);
                    }
                    break;
            }

        }
        else if(!WEBTools.sign_reedite&&ClassConfInit.data.tea.pageNum==ClassConfInit.data.page.curpageNum&&ClassConfInit.data.versionType=='new'){
            WEBTools.target_e=null;
            WEBTools.target_e=WEBTools.e_search(x,y);
            if(WEBTools.target_e){
                if(((WEBTools.graphType=='newrub')||(WEBTools.graphType=='draft'&&WEBTools.target_e.drawingType!=10)|| WEBTools.target_e.drawingType==4)){
                    WEBTools.e_color_init();
                    WEBTools.move_repaint=true;
                    if(WEBTools.target_e.drawingType!=4)
                        WEBTools.target_e.color=ClassConfInit.data.pencil.color_target;
                    else
                        WEBTools.target_e.font_color=ClassConfInit.data.pencil.color_target;
                    if(WEBTools.target_e.id!=WEBTools.last_handle_id){
                        WEBTools.repaint();
                        WEBTools.last_handle_id=WEBTools.target_e.id;
                    }
                }
            }
            else if(WEBTools.move_repaint){
                WEBTools.e_color_init();
                WEBTools.repaint();
                WEBTools.move_repaint=false;
                WEBTools.last_handle_id=-1;
            }
        }

		window.event.preventDefault();
		window.event.stopPropagation();
	},
    mouseup:function (e){
        var re;
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        if(ClassConfInit.data.tea.pageNum==ClassConfInit.data.page.curpageNum&&WEBTools.canDraw){
            if(WEBTools.graphType=='write'){
                re=WEBTools.write_range();
                $('#edit').focus();
            }
            var e=e||window.event||arguments.callee.caller.arguments[0];
            WEBTools.canDraw = false;

            WEBTools.arr_handleData.length=0;

            var x =  Math.round(e.clientX+document.body.scrollLeft - WEBTools.canvasLeft);
            var y =  Math.round(e.clientY+document.body.scrollTop - WEBTools.canvasTop);

            WEBTools.x_min=(x<WEBTools.x_min)?x:WEBTools.x_min;
            WEBTools.x_max=(x>WEBTools.x_max)?x:WEBTools.x_max;
            WEBTools.y_min=(y<WEBTools.y_min)?y:WEBTools.y_min;
            WEBTools.y_max=(y>WEBTools.y_max)?y:WEBTools.y_max;

            var child_div_W= Math.round(WEBTools.x_max-WEBTools.x_min);
            var child_div_H= Math.round(WEBTools.y_max-WEBTools.y_min);

            WEBTools.arr_canvas_temp.push({'x':x,'y':y});

            WEBTools.mouse_move=false;

            switch (WEBTools.graphType){
                case 'pencil':
                    /*封装obj*/
                    if(WEBTools.x_min!=WEBTools.x_max||WEBTools.y_min!=WEBTools.y_max){
                        var obj={
                            'handleType':0,
                            'drawingType':0,
                            'id':WEBTools.svcId,
                            'specialValue':{
                                'pencil_color':ClassConfInit.data.pencil.color,
                                'pencil_size':ClassConfInit.data.pencil.size,
                                'canvasWidth':canvasW,
                                'canvasHeight':canvasH,
                                'child_div_W':child_div_W,
                                'child_div_H':child_div_H,
                                'margin_left':WEBTools.x_min,
                                'margin_top':WEBTools.y_min,
                                'point':WEBTools.arr_canvas_temp.slice(0)
                            }
                        };

                        var e=new paint(obj);

                        e.init_paint(obj);
                        e.handle(WEBTools.context,2);

                        comm_send.UpdatePaintData(JSON.stringify(obj));

                        WEBTools.clearConText();
                    }
                    break;
                case 'sign_pencil':
                    if(WEBTools.x_min!=WEBTools.x_max||WEBTools.y_min!=WEBTools.y_max){
                        /*封装obj*/
                        var obj={
                            'handleType':0,/*代表新的画笔*/
                            'drawingType':10,/*荧光笔*/
                            'id':WEBTools.svcId,
                            'specialValue':{
                                'pencil_color':ClassConfInit.data.pencil.color_sign,
                                'pencil_size':ClassConfInit.data.pencil.size_sign,
                                'canvasWidth':canvasW,/*画布大小*/
                                'canvasHeight':canvasH,/*画布大小*/
                                'child_div_W':child_div_W,/*子画笔大小*/
                                'child_div_H':child_div_H,/*子画笔大小*/
                                'margin_left':WEBTools.x_min,/*子画笔左上角距离画布左上角距离，即左上角的点坐标*/
                                'margin_top':WEBTools.y_min,/*子画笔左上角距离画布左上角距离，即左上角的点坐标*/
                                'point':WEBTools.arr_canvas_temp.slice(0)
                            }
                        };

                        var e=new paint(obj);

                        e.init_paint(obj);
                        e.handle(WEBTools.context,2);

                        comm_send.UpdatePaintData(JSON.stringify(obj));

                        WEBTools.context_bak.restore();
                        WEBTools.clearConText();
                    }
                    break;
                case 'square':
                    if(WEBTools.x_min!=WEBTools.x_max||WEBTools.y_min!=WEBTools.y_max){
                        child_div_W=WEBTools.x_max-WEBTools.x_min;
                        child_div_H=WEBTools.y_max-WEBTools.y_min;

                        /*封装obj*/
                        var obj={
                            'handleType':0,/*代表新的画笔*/
                            'drawingType':2,/*矩形*/
                            'id':WEBTools.svcId,
                            'specialValue':{
                                'pencil_color':ClassConfInit.data.pencil.color,
                                'pencil_size':ClassConfInit.data.pencil.size,
                                'canvasWidth':canvasW,/*画布大小*/
                                'canvasHeight':canvasH,/*画布大小*/
                                'child_div_W':child_div_W,/*子画笔大小*/
                                'child_div_H':child_div_H,/*子画笔大小*/
                                'margin_left':WEBTools.x_min,/*子画笔左上角距离画布左上角距离，即左上角的点坐标*/
                                'margin_top':WEBTools.y_min,/*子画笔左上角距离画布左上角距离，即左上角的点坐标*/
                                'point':WEBTools.arr_canvas_temp.slice(0)
                            }
                        };

                        var e=new paint(obj);

                        e.init_paint(obj);
                        e.handle(WEBTools.context,2);

                        comm_send.UpdatePaintData(JSON.stringify(obj));

                        WEBTools.clearConText();
                    }
                    break;
                case 'rubber':
                    /*封装obj*/
                    var obj={
                        'handleType':0,/*代表新的画笔*/
                        'drawingType':3,
                        'id':WEBTools.svcId,
                        'specialValue':{
                            'pencil_color':ClassConfInit.data.pencil.color,
                            'pencil_size':ClassConfInit.data.pencil.size,
                            'canvasWidth':canvasW,/*画布大小*/
                            'canvasHeight':canvasH,/*画布大小*/
                            'child_div_W':child_div_W,
                            'child_div_H':child_div_H,
                            'margin_left':WEBTools.x_min,
                            'margin_top':WEBTools.y_min,
                            'point':WEBTools.arr_canvas_temp.slice(0)
                        }
                    };
                    var sizerub=ClassConfInit.data.pencil.rubbersize;
                    WEBTools.context.clearRect(x-sizerub/2,y-sizerub/2,sizerub,sizerub);

                    var e=new paint(obj);
                    e.init_paint(obj);
                    e.handle(WEBTools.context,2);
                    comm_send.UpdatePaintData(JSON.stringify(obj));
                    break;
                case 'newrub':
                    var e=WEBTools.e_search(x,y);
                    if(e){
                        /*封装obj*/
                        var obj={
                            'handleType':0,
                            'drawingType':500,
                            'id':WEBTools.svcId,
                            'specialValue':{
                                'id': e.id,
                                'type': 0
                            }
                        };

                        e.color=ClassConfInit.data.pencil.color;

                        e.init_paint(obj);

                        WEBTools.repaint();
                        comm_send.UpdatePaintData(JSON.stringify(obj));
                    }
                    else{
                        WEBTools.e_color_init();
                        WEBTools.repaint();
                    }
                    break;
                case 'write':
                    WEBTools.x_div_click=WEBTools.x_div_click+x-WEBTools.startX+re.x;
                    WEBTools.y_div_click=WEBTools.y_div_click+y-WEBTools.startY+re.y;
                    WEBTools.edit.readOnly='';
                    break;
                case 'draft':
                    if(WEBTools.x_min!=WEBTools.x_max||WEBTools.y_min!=WEBTools.y_max){
                        if(x-WEBTools.startX!=0||y-WEBTools.startY!=0){
                            if(WEBTools.target_e&&!WEBTools.sign_reedite){
                                //首先判断目标对象是不是超出了边界(四种情况)
                                var s=canvasW/WEBTools.target_e.canvasWidth;
                                if(s*(WEBTools.target_e.margin_left+WEBTools.target_e.drag_left)<0){
                                    WEBTools.target_e.drag_left= Math.round(0-WEBTools.target_e.margin_left);
                                }
                                if(s*(WEBTools.target_e.margin_top+WEBTools.target_e.drag_top)<0){
                                    WEBTools.target_e.drag_top= Math.round(0-WEBTools.target_e.margin_top);
                                }
                                if(s*(WEBTools.target_e.margin_left+WEBTools.target_e.drag_left+WEBTools.target_e.child_div_W)>canvasW){
                                    WEBTools.target_e.drag_left= Math.round((canvasW-10)/s-WEBTools.target_e.child_div_W-WEBTools.target_e.margin_left);
                                }
                                if(s*(WEBTools.target_e.margin_top+WEBTools.target_e.drag_top+WEBTools.target_e.child_div_H)>canvasH){
                                    WEBTools.target_e.drag_top= Math.round(canvasH/s-WEBTools.target_e.child_div_H-WEBTools.target_e.margin_top);
                                }

                                WEBTools.clearConText();

                                /*封装obj*/
                                var obj={
                                    'handleType': 0,
                                    'drawingType':500,
                                    'id': WEBTools.svcId,
                                    'specialValue':{
                                        'id': WEBTools.target_e.id,
                                        'type':1,
                                        'drag_left': WEBTools.target_e.drag_left,
                                        'drag_top': WEBTools.target_e.drag_top
                                    }
                                };

                                WEBTools.target_e.init_paint(obj);
                                WEBTools.target_e.handle(WEBTools.context,2);

                                comm_send.UpdatePaintData(JSON.stringify(obj));
                            }
                        }
                    }else{
                        WEBTools.repaint();
                    }
                    break;
                default :
                    break;
            }

            if(WEBTools.graphType!='write'){
                WEBTools.clearConText();
                WEBTools.draw(WEBTools.graphType);
            }

        }
		window.event.preventDefault();
		window.event.stopPropagation();
	},
    mouseout:function (e){
        var target = e.target || e.srcElement;
        if(WEBTools.canDraw&&target.id!='input'&&target.id!='edit'&&WEBTools.graphType!='write')
        {
            WEBTools.mouseup();
        }

		window.event.preventDefault();
		window.event.stopPropagation();
	},

    key_event:function (that){
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        var addW=50*canvasW/800;//增加的宽度
        that.style.wordWrap="normal";
        that.style.whiteSpace="nowrap";
        if(that.scrollWidth>that.clientWidth){//如果超出编辑右边界
            if(get_true(WEBTools.input.style.left,0)+that.scrollWidth+addW>=canvasW-20*canvasW/800)//如果右边到达边界
            {
                WEBTools.input.style.width=canvasW-20*canvasW/800-get_true(WEBTools.input.style.left)+'px';
                that.style.width=$("#input").width()+'px';
                that.style.whiteSpace="pre-wrap";
                that.style.wordWrap="break-word";
            }
            else{//右边没有达到边界
                that.style.width=that.scrollWidth+addW+"px";
                WEBTools.input.style.width=$("#edit").width()+'px';
            }
        }
        if(that.scrollHeight>that.clientHeight){
            //判断是否下边超出
            if(get_true(WEBTools.input.style.top,0)+that.scrollHeight+10*canvasH/800<=canvasH){
                that.style.height=that.scrollHeight+"px";
                WEBTools.input.style.height=$("#edit").height()+'px';
            }
            else//超出
            {
                that.value=WEBTools.text_temp;
            }
        }
        else
        {
            if(that.value.length<WEBTools.text_temp.length){//删除时
                //下面是进行文本框高度的调节
                WEBTools.span_wid.value="";
                WEBTools.span_wid.style.font=(ClassConfInit.data.font.fontSize*canvasW/800)+"px "+ClassConfInit.data.font.fontstyle;
                WEBTools.span_wid.style.width=that.style.width;
                WEBTools.span_wid.style.height='0px';
                WEBTools.span_wid.style.whiteSpace="pre-wrap";
                WEBTools.span_wid.style.wordBreak='break-all';
                WEBTools.span_wid.value=that.value;
                that.style.height=WEBTools.span_wid.scrollHeight+'px';

                WEBTools.input.style.height=that.style.height;
                WEBTools.span_wid.style.whiteSpace="nowrap";
                if(that.value.length<1*canvasW/800&&(that.value.indexOf('\n')==-1||that.value.indexOf('\r\n')==-1)){
                    WEBTools.input.style.width=(ClassConfInit.data.font.fontSize)*canvasW/800+'px';
                    WEBTools.edit.style.width=(ClassConfInit.data.font.fontSize)*canvasW/800+'px';
                }
            }
            WEBTools.text_temp=that.value;
        }
    },
    write_start:function (x,y){
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        WEBTools.edit.autofocus="true";
        WEBTools.sign_write=true;
        WEBTools.text_temp="";
        WEBTools.edit.value="";
        WEBTools.span_wid.value='';
        var w=Math.round((ClassConfInit.data.font.fontSize)*canvasW/800);
        var h=Math.round((ClassConfInit.data.font.fontSize)*canvasW/800);
        var b=Math.round(4*canvasW/800);

        y=((y+h+b+10)>canvasH)?(canvasH-h-b-10):y;
        x=((x+w+b+10)>canvasW)?(canvasW-w-b-10):x;

        $('#input').css({
            'border':'dashed '+b+'px blue',
            'height':h+2*b+'px',
            'width':w+'px',
            'z-index':5,
            'display':'block',
            'left':x+'px',
            'top':y+'px',
        })

        $('#edit').css({
            'height':h+'px',
            'width':w+'px',
            'display':'block',
            'font':'bold '+Math.round(ClassConfInit.data.font.fontSize*canvasW/800)+"px "+ClassConfInit.data.font.fontstyle,
            'white-space':'nowrap'
        });

        $('#span_wid').css({
            'font':'bold '+Math.round(ClassConfInit.data.font.fontSize*canvasW/800)+"px "+ClassConfInit.data.font.fontstyle
        });

        $('#edit').focus();
        WEBTools.x_div_click=x;
        WEBTools.y_div_click=y;
        WEBTools.x_write=x;
        WEBTools.y_write=y;
    },
    write_writing: function () {//处理文字编辑时，未点击白板，点击工具栏
      if(WEBTools.input.style.display!='none'){
          //非重编状态并且内容不为空 或者 处于再编辑状态下
          WEBTools.write_end(1);
      }
    },
    write_end:function (s){//处理输入过程中更换工具
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        WEBTools.input.style.display="none";
        WEBTools.edit.style.display="none";
        WEBTools.sign_write=false;
        WEBTools.arr_handleData.length=0;
        var theString="";
        var changedStr='';
        var replacedStr='';
        theString=WEBTools.edit.value.toString();
        if(theString!=''){
            var str_temp="";
            var recordI=0;//防止死循环

            WEBTools.span_wid.value="";

            WEBTools.span_wid.style.wordWrap="normal";
            WEBTools.span_wid.style.whiteSpace="nowrap";

            WEBTools.span_wid.style.width=Math.round($('#edit').width()+2*4*canvasW/800)+'px';

            for(var i=0;i< theString.length;i++,recordI++){
                if(theString.charAt(i)!="\n"&&theString.charAt(i)!="\r\n")
                {//没有回车
                    WEBTools.span_wid.value+= theString.charAt(i);
                    if((WEBTools.span_wid.scrollWidth>WEBTools.span_wid.clientWidth))//换行标志
                    {
                        str_temp+= theString.charAt(i);
                        str_temp+='/u0022';
                        changedStr+=str_temp;
                        WEBTools.span_wid.value="";
                        str_temp="";
                    }else{//没有换行
                        str_temp+= theString.charAt(i);
                        if(i+1== theString.length){//末尾
                            changedStr+=str_temp;
                        }
                    }
                }
                else
                {//回车处理
                    str_temp+='/u0022';
                    changedStr+=str_temp;
                    WEBTools.span_wid.value="";
                    str_temp="";
                }
            }
            //遵循规则：
            //   ‘/’——>‘//’  \\r——>/u0023 \\n——>/u0024  \\——>/u0025 '——>/u0027  回车——>/u0022
            replacedStr=changedStr.replace(/\\/g,"\\\\").replace(/\\\\r/g,'/u0023').replace(/\\\\n/g,'/u0024').replace(/\\\\/g,'/u0025').replace(/'/g,'/u0027');
        }

        if(!WEBTools.sign_reedite){
            if(theString!=''){//防止空文本发送
                /*封装obj*/
                var obj={
                    'handleType':0,
                    'drawingType':4,
                    'id':WEBTools.svcId,
                    'specialValue':{
                        'font':{
                            'font_color':ClassConfInit.data.pencil.color,
                            'font_size':Math.round(ClassConfInit.data.font.fontSize*canvasW/800),
                            'font_style':ClassConfInit.data.font.fontstyle
                        },
                        'canvasWidth':canvasW,
                        'canvasHeight':canvasH,
                        'child_div_W': Math.round($("#edit").width()),
                        'child_div_H': Math.round($('#edit').height()),
                        'margin_left':WEBTools.x_write,/*子画笔左上角距离画布左上角距离，即左上角的点坐标*/
                        'margin_top':WEBTools.y_write,/*子画笔左上角距离画布左上角距离，即左上角的点坐标*/
                        'str_text':replacedStr
                    }
                };
                comm_send.UpdatePaintData(JSON.stringify(obj));
                var e=new paint(obj);
                e.init_paint(obj);
                e.handle(WEBTools.context);

                if(!s){//输入过程中正常更换工具操作
                    WEBTools.clearConText();
                    WEBTools.draw('write',false);
                }

            }
        }
        else{
            var s=WEBTools.target_e.canvasWidth/canvasW;
            WEBTools.target_e.child_div_W= Math.round(($("#edit").width())*s);
            WEBTools.target_e.child_div_H= Math.round(($('#edit').height())*s);

            WEBTools.target_e.drag_left= Math.round(WEBTools.x_write*s-WEBTools.target_e.margin_left);
            WEBTools.target_e.drag_top= Math.round(WEBTools.y_write*s-WEBTools.target_e.margin_top);

            /*封装obj*/
            var obj={
                'handleType': 0,
                'drawingType':500,
                'id':WEBTools.svcId,
                'specialValue':{
                    'id':WEBTools.target_e.id,
                    'type':2,
                    'font':{
                        'font_color':ClassConfInit.data.pencil.color,
                        'font_size':Math.round(ClassConfInit.data.font.fontSize*s),
                        'font_style':ClassConfInit.data.font.fontstyle
                    },
                    'child_div_W': WEBTools.target_e.child_div_W,
                    'child_div_H': WEBTools.target_e.child_div_H,
                    'drag_left':WEBTools.target_e.drag_left,
                    'drag_top':WEBTools.target_e.drag_top,
                    'str_text':replacedStr
                }
            };

            comm_send.UpdatePaintData(JSON.stringify(obj));

            WEBTools.target_e.display=1;

            WEBTools.target_e.init_paint(obj);
            WEBTools.target_e.handle(WEBTools.context);

            WEBTools.graphType=WEBTools.last_handle;
            if(WEBTools.last_handle=='write'){
                WEBTools.draw(WEBTools.graphType,false);
            }
            else{
                WEBTools.draw(WEBTools.graphType);
            }

            WEBTools.sign_reedite=false;
            WEBTools.canDraw=false;
        }
        $('#edit').val('');
    },
    write_range:function (){
        var canvasW=WEBTools.canvasWidth,
            canvasH=WEBTools.canvasHeight;
        var x_X= 0,y_Y=0;
        var b=2*Math.round(4*canvasW/800);
        //如果超出
        if((get_true(WEBTools.input.style.left,0)+$("#input").width()+b>=canvasW-10*canvasW/800)){
            x_X=canvasW-get_true(WEBTools.input.style.left,0)-$("#input").width()-b;
            WEBTools.input.style.left=canvasW-10*canvasW/800-$("#input").width()-b+'px';
            WEBTools.x_write=canvasW-10*canvasW/800-$("#input").width()-b;
        }
        if(get_true(WEBTools.input.style.top,0)+$("#input").height()+b>=canvasH){
            y_Y=canvasH-get_true(WEBTools.input.style.top,0)-$("#input").height()-b;
            WEBTools.input.style.top=canvasH-$("#input").height()-b+'px';
            WEBTools.y_write=canvasH-$("#input").height()-b;
        }
        if(get_true(WEBTools.input.style.left,0)<0){
            x_X=0-get_true(WEBTools.input.style.left,0)-b;
            WEBTools.input.style.left=b+'px';
            WEBTools.x_write=b;
        }
        if(get_true(WEBTools.input.style.top,0)<0){
            y_Y=0-get_true(WEBTools.input.style.top,0)-b;
            WEBTools.input.style.top=b+'px';
            WEBTools.y_write=b;
        }
        return {x:x_X,y:y_Y};
    },

    DBClick:function (e){
        var e=e||window.event;
        var x = e.clientX+document.body.scrollLeft - WEBTools.canvasLeft;
        var y = e.clientY+$('#scrollbar1').find('.thumb')[0].offsetTop - WEBTools.canvasTop;
        WEBTools.last_handle=WEBTools.graphType;
        WEBTools.target_e=WEBTools.e_search(x,y);
        if(WEBTools.target_e){
            if(WEBTools.target_e.handleType==0&&WEBTools.target_e.drawingType==4){//如果当前双击的目标是文字

                WEBTools.sign_reedite=true;
                WEBTools.draw('write',true);

                WEBTools.sign_write=true;

                WEBTools.target_e.display=0;
                WEBTools.repaint();
                var tem_text=WEBTools.target_e.point_Arr_text.replace(/\/u0022/g,'\r\n');
                var s=WEBTools.canvasWidth/WEBTools.target_e.canvasWidth;

                $('#input').css({
                    'border':'dashed '+4*WEBTools.canvasWidth/800+'px red',
                    'z-index':5,
                    'display':'block',
                    'width':WEBTools.target_e.child_div_W*s+'px',
                    'height':WEBTools.target_e.child_div_H*s+'px',
                    'left':(WEBTools.target_e.margin_left+WEBTools.target_e.drag_left)*s+'px',
                    'top':(WEBTools.target_e.margin_top+WEBTools.target_e.drag_top)*s+'px'
                });

                $('#edit').css({
                    'border':'0px',
                    'width':WEBTools.target_e.child_div_W*s+'px',
                    'height':WEBTools.target_e.child_div_H*s+'px',
                    'display':'block',
                    'white-space':"pre-wrap",
                    'word-wrap':"break-word",
                    'font':'bold '+WEBTools.target_e.font_size*s+"px "+ClassConfInit.data.font.fontstyle
                })


                WEBTools.edit.value=tem_text;
                WEBTools.x_div_click=(WEBTools.target_e.margin_left+WEBTools.target_e.drag_left)*s;
                WEBTools.y_div_click=(WEBTools.target_e.margin_top+WEBTools.target_e.drag_top)*s;
                WEBTools.x_write=(WEBTools.target_e.margin_left+WEBTools.target_e.drag_left)*s;
                WEBTools.y_write=(WEBTools.target_e.margin_top+WEBTools.target_e.drag_top)*s;
                WEBTools.graphType='write';

                WEBTools.bind(WEBTools.canvas_bak);
                WEBTools.bind(WEBTools.input);
            }
        }
    },

    e_color_init:function (){
        for(var i= 0,j=WEBTools.pDone_Arr.length;i<j;i++){
            if(WEBTools.pDone_Arr[i].drawingType!=10){
                if(WEBTools.pDone_Arr[i].drawingType!=4)
                {
                    WEBTools.pDone_Arr[i].color=WEBTools.pDone_Arr[i].login_type=='tea'?constants.COLORTEA:constants.COLORSTU;
                }
                else{
                    WEBTools.pDone_Arr[i].font_color=WEBTools.pDone_Arr[i].login_type=='tea'?constants.COLORTEA:constants.COLORSTU;
                }
            }
            else{
                WEBTools.pDone_Arr[i].color=WEBTools.pDone_Arr[i].login_type=='tea'?constants.COLORTEA:constants.COLORSTUSIGN;
            }

        }
    },

    e_search:function (x,y){
        var e;
        var s;
        var i,j;
        WEBTools.canvasTop = $("#paint_board").offset().top;
        WEBTools.canvasLeft = $("#paint_board").offset().left;
        for(i= 0,j=WEBTools.pDone_Arr.length;i<j;i++){
            e=WEBTools.pDone_Arr[i];
            s= WEBTools.canvasWidth/ e.canvasWidth;
            if(e.drawingType!=500){
                if(e.display==1&& e.drawingType!=3&&e.handleType==0){
                    if(e.drawingType!=10){
                        if(x>= (e.margin_left+ e.drag_left)*s&&y>= (e.margin_top+ e.drag_top)*s){
                            if(x<= (e.margin_left+ e.child_div_W+ e.drag_left)*s&&y<=(e.margin_top+ e.child_div_H+ e.drag_top)*s){
                                //找到了适合的笔画对象
                                return e;
                            }
                        }
                    }
                    else
                    {
                        if(WEBTools.graphType!='draft'&&(x>= (e.margin_left+ e.drag_left)*s&&y>= (e.margin_top+ e.drag_top)*s)){
                            if(x<= (e.margin_left+ e.child_div_W+ e.drag_left)*s+10*WEBTools.canvasWidth/800&&y<=(e.margin_top+ e.child_div_H+ e.drag_top)*s+10*WEBTools.canvasWidth/800){
                                //找到了适合的笔画对象
                                return e;
                            }
                        }
                    }
                }
            }

        }
        return null;
    },

    handle_back:function (target_id){
        var i,j;
        for(i= 0,j=WEBTools.pDone_Arr.length;i<j;i++){
            if(WEBTools.pDone_Arr[i].id==target_id&&WEBTools.pDone_Arr[i].changeCount!=0){//找到要撤销的线条数据
                WEBTools.clearConText(1);
                var e=WEBTools.pDone_Arr[i];
                e.changeCount--;
                if(e.changeCount==0)//最初创建状态
                {
                    e.display=0;
                    WEBTools.svcId--;
                }
                else{//创建之后进行了改动
                    var del=e.Arr_data_handle.pop();
                    if(del.drawingType==500&&del.specialValue.type==0)
                        e.display=1;
                    else{
                        var obj=e.Arr_data_handle[e.Arr_data_handle.length-1];
                        e.init_paint(obj,1);
                    }
                }
                WEBTools.repaint();
            }
        }
    },

    handle_clear:function (){
        var target_e;
        for(var i=0,j=WEBTools.pDone_Arr.length;i<j;i++){
            target_e=WEBTools.pDone_Arr[i];
            target_e.display=0;
            target_e.changeCount=0;
        }
        WEBTools.order_list.length=0;
        WEBTools.repaint();
        if(ClassConfInit.data.candraw){
            if(WEBTools.last_handle!='write'){
                WEBTools.draw(WEBTools.last_handle);
            }else
            {
                WEBTools.draw(WEBTools.last_handle,false);
            }
        }
        WEBTools.svcId=1;
    },

    clearConText:function (type){
        try{
            if(!type)
                WEBTools.context_bak.clearRect(0,0,WEBTools.canvasWidth,WEBTools.canvasHeight);
            else
            {
                WEBTools.context.clearRect(0,0,WEBTools.canvasWidth,WEBTools.canvasHeight);
                WEBTools.context_bak.clearRect(0,0,WEBTools.canvasWidth,WEBTools.canvasHeight);
            }
        }catch(e){

        }
    },

    repaint: function () {
        if(ClassConfInit.data.page.curpageNum==ClassConfInit.data.tea.pageNum){
            WEBTools.clearConText(1);
            var e;
            var i=0,j=WEBTools.pDone_Arr.length;
            while(i<j){
                e=WEBTools.pDone_Arr[i];
                e.handle(WEBTools.context,2);
                i++;
            }
        }
    }
}

var paint= function (obj) {
    //父类
    this.Arr_data_handle=new Array();//用于存储每一笔的每一步的信息

    if(obj.drawingType==4)//文字
    {
        this.login_type=obj.specialValue.font.font_color==constants.COLORTEA?'tea':'stu';
    }
    else
    {
        this.login_type=obj.specialValue.pencil_color==constants.COLORTEA?'tea':'stu';
    }
    this.version_type=ClassConfInit.data.versionType;
    this.id=WEBTools.svcId;
    this.handleType=obj.handleType;
    this.drawingType=obj.drawingType;
    WEBTools.order_list.push(WEBTools.svcId);//创建新的画笔，一定会走paint
    WEBTools.pDone_Arr.push(this);
    WEBTools.svcId++;
}

//初始化信息
paint.prototype.init_paint= function (obj,type) {//根据分析数据去选择操作
    if(!type)
        this.Arr_data_handle.push(obj);
    if(obj.handleType==0){/*增*/
        if(obj.drawingType!=500){
            this.canvasWidth=obj.specialValue.canvasWidth;
            this.canvasHeight=obj.specialValue.canvasHeight;
            //以后会变化的,现在赋默认值
            this.changeCount=1;
            this.display=1;

            this.child_div_W=obj.specialValue.child_div_W;
            this.child_div_H=obj.specialValue.child_div_H;
            this.margin_left=obj.specialValue.margin_left;
            this.margin_top=obj.specialValue.margin_top;
            this.drag_left=0;
            this.drag_top=0;
            if(obj.drawingType==4)//文字
            {
                this.font_color=obj.specialValue.font.font_color;
                this.font_size=obj.specialValue.font.font_size;
                this.font_style=obj.specialValue.font.font_style;
                this.point_Arr_text=obj.specialValue.str_text.replace(/\/u0023/g,'\\r').replace(/\/u0024/g,'\\n').replace(/\/u0025/g,'\\').replace(/\/u0027/g,"'");
            }
            else
            {
                this.color=obj.specialValue.pencil_color;
                this.size=obj.specialValue.pencil_size;
                this.point_Arr_text=obj.specialValue.point;
            }
        }else{
            WEBTools.order_list.push(this.id);
            WEBTools.svcId++;
            if(!type)
                this.changeCount++;
            switch (obj.specialValue.type){
                case 0://新版橡皮擦
                    this.display=0;
                    break;
                case 1://拖动
                    this.drag_left=obj.specialValue.drag_left;
                    this.drag_top=obj.specialValue.drag_top;
                    break;
                case 2://重写
                    this.child_div_W=obj.specialValue.child_div_W;
                    this.child_div_H=obj.specialValue.child_div_H;
                    this.drag_left=obj.specialValue.drag_left;
                    this.drag_top=obj.specialValue.drag_top;
                    this.point_Arr_text=obj.specialValue.str_text.replace(/\/u0023/g,'\\r').replace(/\/u0024/g,'\\n').replace(/\/u0025/g,'\\').replace(/\/u0027/g,"'");
                    break;
                default :
                    break;
            }
        }
    }
    else if(obj.handleType==1){
        /*删*/
    }else if(obj.handleType==2){
        /*改*/
    }
}

//按类型操作
paint.prototype.handle= function (target_context) {
    try{
        if(this.display==1&&ClassConfInit.data.page.curpageNum==ClassConfInit.data.tea.pageNum){
            switch (this.drawingType){
                case 0://划线
                    this.canvas_pencil(target_context);
                    break;
                case 2://长方形
                    this.canvas_square(target_context);
                    break;
                case 10://荧光笔
                    this.canvas_sign(target_context);
                    break;
                case 4://文字
                    this.canvas_write(target_context);
                    break;
                case 3://老版橡皮擦
                    this.canvas_rubber(target_context);
                    break;
                default :
                    break;
            }
        }
    }catch(e){
        console.log('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when paint.prototype.handle : '+e);
        comm_send.HBlog('['+constants.timer.toLocaleTimeString()+']'+'----->'+'error happened when paint.prototype.handle : '+e);
    }

}

//画笔
paint.prototype.canvas_pencil= function (target_context) {
    var s=WEBTools.canvasWidth/this.canvasWidth;
    var s2=WEBTools.canvasWidth/800;
    target_context.lineCap='round';
    target_context.lineJoin="round";
    target_context.strokeStyle= this.color;
    target_context.lineWidth = this.size*s2;
    target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
    target_context.beginPath();
    for(var i=1;i<this.point_Arr_text.length;i++){
        target_context.lineTo((this.point_Arr_text[i].x+this.drag_left)*s,(this.point_Arr_text[i].y+this.drag_top)*s);
    }
    target_context.stroke();
}

//长方形
paint.prototype.canvas_square= function (target_context) {
    var s=WEBTools.canvasWidth/this.canvasWidth;
    var s2=WEBTools.canvasWidth/800;

    target_context.strokeStyle= this.color;
    target_context.lineJoin="round";
    target_context.lineWidth = this.size*s2;
    target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
    target_context.beginPath();
    target_context.lineTo((this.point_Arr_text[1].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
    target_context.lineTo((this.point_Arr_text[1].x+this.drag_left)*s,(this.point_Arr_text[1].y+this.drag_top)*s);
    target_context.lineTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[1].y+this.drag_top)*s);
    target_context.lineTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
    target_context.closePath();
    target_context.stroke();
}

//荧光笔
paint.prototype.canvas_sign= function (target_context) {
    target_context.save();
    var s=WEBTools.canvasWidth/this.canvasWidth;

    target_context.lineCap='round';
    target_context.lineJoin="round";
    target_context.strokeStyle=this.color;
    target_context.globalAlpha=0.3;
    target_context.globalCompositeOperation='destination-over';
    target_context.lineWidth=this.size*WEBTools.canvasWidth/800;
    target_context.moveTo((this.point_Arr_text[0].x+this.drag_left)*s,(this.point_Arr_text[0].y+this.drag_top)*s);
    target_context.beginPath();
    for(var i=2;i<this.point_Arr_text.length;i++){
        target_context.lineTo((this.point_Arr_text[i].x+this.drag_left)*s,(this.point_Arr_text[i].y+this.drag_top)*s);
    }
    target_context.stroke();
    target_context.restore();
}

//文字
paint.prototype.canvas_write= function (target_context){
    var theString=this.point_Arr_text.replace('/\/u0027/g','\'');
    var s=WEBTools.canvasWidth/this.canvasWidth;
    var hei_point=(this.margin_top+this.drag_top)*s;
    var wid_point=(this.margin_left+this.drag_left)*s;
    var words=[];
    var i,j;

    target_context.font='bold '+Math.round(this.font_size*s)+"px "+ClassConfInit.data.font.fontstyle;
    target_context.fillStyle=this.font_color;

    words=theString.split(/\/u0022/);

    for(i=0,j=words.length;i<j;i++){
        hei_point+=(this.font_size)*s;
        target_context.fillText(words.shift(),wid_point,hei_point);
    }
}

//旧版橡皮擦
paint.prototype.canvas_rubber= function (target_context) {
    var s=WEBTools.canvasWidth/this.canvasWidth;
    var sizerub=ClassConfInit.data.pencil.rubbersize;
    target_context.lineCap='round';
    target_context.lineJoin="round";
    for(var i=0;i<this.point_Arr_text.length;i++){
        target_context.clearRect((this.point_Arr_text[i].x)*s-sizerub/2,(this.point_Arr_text[i].y)*s-sizerub/2,sizerub,sizerub);
    }
}





