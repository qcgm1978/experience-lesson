var CreatePageContain= function () {
    var str1=
        '<div id="update_cue">' +
            '<div class="cue_bak">' +
                '<div id="cue_close" class="cue_close"></div>'+
                '<div class="cue_base">AC教室又增加新功能啦，升级后即可使用.提示：可在AC主界面左下角系统菜单中点击升级</div>'+
                '<div id="cue_stop" class="cue_stop">不再提示</div>'+
            '</div>' +
        '</div>';
    var str2='<div class="workSpace" id="workSpace">'+
        '<div id="scrollbar1">' +
            '<div class="viewport" id="dsa">' +
                '<div class="overview" id="overview">' +
                    '<div id="workContainer">' +
                        '<div class="itemCon"><ul><p class="item_title">' +
                            '<span class="title1" data-num="1">1.Warm up</span>'+
                            '<span class="title2" data-num="2">2.Presentation</span>'+
                            '<span class="title3" data-num="3">3.Practice</span>'+
                            '<span class="title4" data-num="4">4.Production</span>'+
                            '<span class="title5" data-num="5">5.Warm-up</span>'+
                        '</p></ul>' +
                        '<div class="progress"><div class="left"></div><div class="right"></div></div></div>' +
                        '<div class="content">' +
                            '<div class="content_bak">'+
                            '<iframe class="showDomain" id="showDomain" scrolling="no"></iframe>'+
                            '<div class="boardResetUp"></div>'+
                            '<div class="boardResetDown"></div>'+
                            '</div>'+
                        '</div>'+
                    '</div>' +
                '</div>' +
            '</div>' +
            '<div class="scrollbar">' +
                '<div class="track">' +
                    '<div class="thumb">' +
                        '<div class="end"></div>' +
                    '</div>' +
                '</div>' +
            '</div>' +
        '</div>'+
        '</div>';

    $('#mainContainer').append(str1+str2);
    $('#scrollbar1').tinyscrollbar();
    ClassConfInit.data.conf.sigh_contain=true;
}

var CreatePageMostTurnpage= function () {
    var str3=
        '<div class="toolbar" id="toolbar_id">' +
        '<div class="toolContain">' +
        '<div class="toolbarLeft">' +

        '</div>'+
        '<div class="toolbarCenter">' +

        '</div>'+
        '<div class="toolbarRight">' +
        '<div id="tool_ppt_control" class="tool_ppt_class"></div>'+
        '<div title="Previous Page" id="previousPage"></div>' +
        '<input type="tel" id="pageNumber" class="pageNumber" value="1"/>' +
        '<span id="numPages" class="toolbarLabel">/ 5</span>' +
        '<div title="Next Page" id="nextPage"  tabindex="14"></div>' +
        '<div id="update_tea" title = "updatePage"></div>' +
            //'<div id="helpBut"></div>'+
        '</div>'+
        '</div>'+
        '</div>';
    $('#mainContainer').append(str3);
    ClassConfInit.data.conf.sign_page=true;
}

var CreatePageMostTools= function () {
    var str1='<div class="tool_m_l_r" id="toolbar_left" style="left: 0px;"></div>'
        +'<div class="tool_m_l_r" id="toolbar_right" style="right: 0px;"></div>'
        +'<div class="tool_m_l_r" id="toolbar_bottom" style="bottom: 0px;"></div>';
    var str2=
        '<div id="Center_chose">' +
        '<div class="con_chose">' +
        '<div id="chose_font">' +
        '<div id="font_small"></div>' +
        '<div id="font_big"></div>' +
        '</div>' +
        '</div>' +
        '</div>'+
        '<div class="outerCenter" id="outerCenter">'+
        '<div id="tool_bar_center">'+
        '<div id="drag_shift" title="移动"></div>' +
        '<div id="hand_line" title = "画笔"></div>' +
        '<div id="hand_signLine" title = "荧光笔"></div>' +
        '<div id="hand_square" title = "矩形"></div>' +
        '<div id="hand_write" title = "文字"></div>' +
        '<div id="hand_rubber" title = "橡皮擦"></div>' +
        '<div id="hand_drag" title = "拖动"></div>' +
        '<div id="hand_back" title = "回退"></div>' +
        '<div id="hand_clear" title = "清除"></div>'+
        '<div id="hand_magic" title = "魔法表情"></div>'+
        '</div>'+
        '</div>';
    var str3='<div id="tool_move"></div>';

    $('#mainContainer').append(str1+str2+str3);
    ClassConfInit.data.conf.sign_tools=true;
}

var CreateDrawBoard= function () {
    var str='<div id="paint_board" class="paint_board">' +
        '<div id="input" autofocus="autofocus" contenteditable="true" tabindex="-1">' +
        '<textarea id="edit"></textarea>' +
        '</div>' +
        '<div id="mouseTea"><canvas id="canvasMouse" width="20" height="20"></canvas></div>'+
        '<canvas class="canvas" id="canvas">浏览器不支持</canvas>' +
        '<canvas class="canvas" id="canvas_bak"></canvas>' +
        '</div>'+
        '<textarea id="span_wid"></textarea>';
    $('#workContainer').find('.content_bak').append(str);
    ClassConfInit.data.conf.sign_draw=true;
    WEBTools.init();//初始化
}

var CreateCourse= function (type) {
    switch (type){
        case 'pdf':
            $('#showDomain').attr('src','./src/ppt/00/index.html');
            break;
        case 'ppt':
            break;
        default :
            break;
    }
    commParIf.init();
}

var CreateScrolldata= function () {
    var str='<div class="scroll_tea"></div>';
    $('#mainContainer').append(str);
    ClassConfInit.data.conf.sign_scroll=true;
}

var CreateFixeddata= function () {
    var str='<div class="fixdata_tea">Your lesson is recorded for quality purposes. And a quality evaluator might be observing your lesson.<div id="data_close"></div></div>';
    $('#mainContainer').append(str);
    ClassConfInit.data.conf.sign_fixdata=true;
}

var CreatePageYoung= function () {

}

var CreatePagePpt= function () {

}

































