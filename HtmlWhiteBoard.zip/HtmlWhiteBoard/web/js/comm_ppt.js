﻿/**
 * Created by Administrator on 2016/8/10.
 */
var commData_set= function (type,objStr) {
    try{
        var parentCon=$(window.parent.document).contents().find("#showDomain")[0].contentWindow;
        parentCon.action(type,objStr);
    }catch (e){
        console.error('error happened for commData_set :'+e);
    }
}
var curState=''
var commData_send= function (type,valObj) {
    try{
        switch (type){
            case 'loaded':
                /*ppt__________________________________________________________________________________________start*/
                var data=ClassConfInit.data;
                var teaState=data.name_login=='tea'?'in':(data.tea.login?'in':'out');
                var classT=data.Class1V1?'1v1':'1vN';
                var pptObj={
                    userInfo:{
                        userType:data.name_login,
                        userId:data.obj_UserData.userid,
                        teaState:teaState,
                        curState:curState,
                        page:data.page.curpageNum
                    },
                    classInfo:{
                        classType:classT
                    },
                    frameInfo:{
                        width:1047,
                        height:598
                    }
                };
                commData_set('init',JSON.stringify(pptObj));
               
                /*ppt__________________________________________________________________________________________end*/
                break;
            case 'data':
                var obj={
                    'handleType':0,
                    'drawingType':500,
                    'id':WEBTools.svcId,
                    'specialValue':{
                        'type':10,
                        'value':JSON.parse(valObj)
                    }
                };
                WEBTools.svcId++;
                comm_send.UpdatePptData(JSON.stringify(obj));
                break;
            case 'conf':
            {
                var obj = {
                    'handleType': 0,
                    'drawingType': 500,
                    'id': WEBTools.svcId,
                    'specialValue': {
                        'type': 11,
                        'value': valObj
                    }
                };
                curState=obj.specialValue.value.value.curState
                WEBTools.svcId++;
                comm_send.UpdatePptData(JSON.stringify(obj));
                if (curState=='startClass') {
                    ClassConfInit.data.page.curpageNum = 1;
                    ClassConfInit.data.timeArr = [];
                    changePage();
                }else if(curState=='startPra'){
                    var iniObj={
                        userInfo:{

                            curState:curState,
                        }
                    };
                    commData_set('init',JSON.stringify(iniObj));

                }
                break;
            }
            case 'resetHref':
                var obj={
                    'handleType':0,
                    'drawingType':500,
                    'id':WEBTools.svcId,
                    'specialValue':{
                        'type':12,
                        'value':valObj
                    }
                };
                WEBTools.svcId++;
                comm_send.UpdatePptData(JSON.stringify(obj));
                break;
            case 'setPage':
                var s=parseInt(valObj);
               
                ClassConfInit.data.page.count=s;
                if(ClassConfInit.data.conf.sign_page){//如果存在这个模块
                    commParIf.init(s);
                }
                break;
            default:
                console.error('undefined type for commData_get,type is :'+type);
                break;
        }
    }catch (e){
        console.error('error happened for commData_get :'+e);
    }
}













