/**
 * Created by Administrator on 2016/1/28.
 */
var tools=(function () {
    var tool_e=null;
    var tool_e_three;
    var sign_tool_state=0;//表示工具栏的方位 1 left 2 right 0 bottom
    var ToolsEventBind= function () {//函数绑定
        if(ClassConfInit.data.conf.sign_tools){
            document.getElementById('tool_bar_center').onmousedown= function (event) {
                tool_e_three.getTarget(event,'down',21);
                var handle_target=event.target.id;
                $('#Center_chose').css('display','none');
                if(handle_target!='drag_shift'&&handle_target!='tool_bar_center'){
                    switch (handle_target){
                        case 'hand_line':
                            WEBTools.draw('pencil');
                            break;
                        case 'hand_signLine':
                            WEBTools.draw('sign_pencil');
                            break;
                        case 'hand_square':
                            WEBTools.draw('square');
                            break;
                        case 'hand_write':
                            WEBTools.draw('write');
                            $('#Center_chose').css('display','block');
                            if(ClassConfInit.data.font.fontSize==25){
                                document.getElementById('font_small').style.backgroundPositionX='0px';
                                document.getElementById('font_big').style.backgroundPositionX='-48px';
                            }else{
                                document.getElementById('font_big').style.backgroundPositionX='0px';
                                document.getElementById('font_small').style.backgroundPositionX='-48px';
                            }
                            break;
                        case 'hand_rubber':
                            if(ClassConfInit.data.tools.rub){
                                WEBTools.draw('rubber');
                            }else
                            {
                                WEBTools.draw('newrub');
                            }
                            break;
                        case 'hand_drag':
                            WEBTools.draw('draft');
                            break;
                        case 'hand_back':
                            WEBTools.draw('back');
                            break;
                        case 'hand_clear':
                            WEBTools.draw('clear');
                            break;

                    }
                }
            }
            document.getElementById('tool_bar_center').onmousemove= function (event) {
                tool_e_three.getTarget(event,'over',21);
            }
            document.getElementById('tool_bar_center').onmouseout= function (event) {
                tool_e_three.getTarget(event,'out',21);
            }

            document.getElementById('font_small').onmouseout= function (event) {
                if(ClassConfInit.data.font.fontSize==25)
                    tool_e_three.getTarget(event,'out',24);
            };
            document.getElementById('font_small').onmouseover= function (event) {
                if(ClassConfInit.data.font.fontSize==25)
                    tool_e_three.getTarget(event,'over',24);
            }
            document.getElementById('font_small').onmousedown= function (event) {
                if(ClassConfInit.data.font.fontSize==25){
                    tool_e_three.getTarget(event,'down',24);
                    ClassConfInit.data.font.fontSize=16;
                }
                $('#Center_chose').css('display','none');
            }

            document.getElementById('font_big').onmouseout= function (event) {
                if(ClassConfInit.data.font.fontSize==16)
                    tool_e_three.getTarget(event,'out',24);
            };
            document.getElementById('font_big').onmouseover= function (event) {
                if(ClassConfInit.data.font.fontSize==16)
                    tool_e_three.getTarget(event,'over',24);
            }
            document.getElementById('font_big').onmousedown= function (event) {
                if(ClassConfInit.data.font.fontSize==16){
                    tool_e_three.getTarget(event,'down',24);
                    ClassConfInit.data.font.fontSize=25;
                }
                $('#Center_chose').css('display','none');
            }
            document.getElementById('tool_ppt_control').onclick=function(event){
                if(event.target.className.indexOf('tool_ppt_class')!=-1){
                    $('#tool_ppt_control').removeClass('tool_ppt_class');
                    var obj={
                        type:'classCont',
                        value:{
                            curState:'startClass'
                        }
                    };
                    commData_send('conf',obj);
                }else if(event.target.className.indexOf('tool_ppt_practice')!=-1){
                    $('#tool_ppt_control').removeClass('tool_ppt_practice');
                    var obj={
                        type:'classCont',
                        value:{
                            curState:'startPra'
                        }
                    };
                    commData_send('conf',obj);
                }
            }
        }
        if(ClassConfInit.data.conf.sign_page){
            document.getElementById('previousPage').onmouseout= function (event) {
                tool_e_three.getTarget(event,'out',20);
            };
            document.getElementById('previousPage').onmouseover= function (event) {
                tool_e_three.getTarget(event,'over',20);
            }
            document.getElementById('previousPage').onmousedown= function (event) {
                tool_e_three.getTarget(event,'down',20);
            }

            document.getElementById('nextPage').onmouseout= function (event) {
                tool_e_three.getTarget(event,'out',20);
            };
            document.getElementById('nextPage').onmouseover= function (event) {
                tool_e_three.getTarget(event,'over',20);
            }
            document.getElementById('nextPage').onmousedown= function (event) {
                tool_e_three.getTarget(event,'down',20);
            }

            document.getElementById('update_tea').onmouseout= function (event) {
                tool_e_three.getTarget(event,'out',12);
            };
            document.getElementById('update_tea').onmouseover= function (event) {
                tool_e_three.getTarget(event,'over',12);
            }
            document.getElementById('update_tea').onmousedown= function (event) {
                tool_e_three.getTarget(event,'down',12);
            }
            $('.item_title').bind('click', function (e) {
                ClassConfInit.data.page.curpageNum=e.target.dataset.num;
                changePage();
            });

            document.getElementById('previousPage').onclick= function (event) {
                //throttle(tool_e.tool_pre);
                //if(ClassConfInit.data.page.curpageNum>1){//Ϊ��ʵ�����ò���
                //    var obj={
                //        'type':'pre',
                //        'targetPage':ClassConfInit.data.page.curpageNum-1
                //    }
                //    comm_type_send_set('pagechange',JSON.stringify(obj));
                //}
                if(ClassConfInit.data.page.curpageNum>1){
                    ClassConfInit.data.page.curpageNum--;
                    changePage();
                }
            };

            document.getElementById('nextPage').onclick= function () {
                //throttle(tool_e.tool_next);
                //if(ClassConfInit.data.page.curpageNum<ClassConfInit.data.page.count){//Ϊ��ʵ�����ò���
                //    var obj={
                //        'type':'next',
                //        'targetPage':ClassConfInit.data.page.curpageNum+1
                //    }
                //    comm_type_send_set('pagechange',JSON.stringify(obj));
                //}
                if(ClassConfInit.data.page.curpageNum<ClassConfInit.data.page.count){
                    ClassConfInit.data.page.curpageNum++;
                    changePage();
                }
            };

            $('.boardResetUp').bind('click', function () {
                $('#paint_board').animate({top:'0px'},1000, function () {
                    $('#outerCenter').css('display','block');
                });
                $('.boardResetUp').animate({top:'547px'},1000, function () {
                    $('.boardResetDown').css({
                        'display':'block',
                        'top':'547px'
                    });
                    $('.boardResetUp').css('display','none');
                });

            });
            $('.boardResetDown').bind('click', function () {
                $('#paint_board').animate({top:'-600px'},1000, function () {
                    $('#outerCenter').css('display','none');
                });
                $('.boardResetDown').animate({top:'0px'},1000, function () {
                    $('.boardResetDown').css('display','none');
                    $('.boardResetUp').css({
                        'display':'block',
                        'top':'0px'
                    });
                });

            });

            document.getElementById('pageNumber').addEventListener('click',
                function() {
                    this.select();
                });

            document.getElementById('pageNumber').addEventListener('change',
                function() {
                    //tool_e.tool_skip(this.value);
                    //if(this.value<ClassConfInit.data.page.count&&this.value>0){//Ϊ��ʵ�����ò���
                    //    var obj={
                    //        'type':'skip',
                    //        'targetPage':this.value
                    //    }
                    //    comm_type_send_set('pagechange',JSON.stringify(obj));
                    //}else{
                    //    tool_e.tool_skip(this.value);
                    //}
                });

            document.getElementById('update_tea').onclick= function () {
                //tool_e.tool_update();
                var obj={
                    'type':'skip',
                    'targetPage':ClassConfInit.data.tea.pageNum
                }
                comm_type_send_set('pagechange',JSON.stringify(obj));
            }
        }
    };

    var init_tool= function () {
        if(!tool_e){
            tools.tool_e=new tool();
            ToolsEventBind();
        }
        tool_e_three=(!tool_e_three)?new tool_three():tool_e_three;
        if(ClassConfInit.data.conf.sign_tools){
            css_reInit(tools.sign_tool_state);//初始化工具条
            tools.tool_e.resize_tool();
        }
    };

    var tray_pointer= function (s,e) {//实现工具栏的吸附和拖拽
        var mousemove= function (e) {
            e=e||arguments.callee.caller.arguments[0]||window.event;
            x = e.clientX;
            y = e.clientY;

            $('#outerCenter').css("left",left_start+x-startX);
            $('#outerCenter').css("top",(top_start+y-startY));

            if(left_start+x-startX<=$('#mainContainer').width()/800*50){//在左侧
                tools.tool_e.bottom_tool.style.display='none';
                tools.tool_e.right_tool.style.display='none';
                tools.tool_e.left_tool.style.display='block';
                tools.sign_tool_state=1;
            }
            else if(left_start+x-startX+$('#outerCenter').width()>=$('#mainContainer').width()-$('#mainContainer').width()/800*50){//在右侧
                tools.tool_e.right_tool.style.display='block';
                tools.tool_e.left_tool.style.display='none';
                tools.tool_e.bottom_tool.style.display='none';
                tools.sign_tool_state=2;
            }
            else//其他区域默认在底部
            {
                tools.tool_e.bottom_tool.style.display='block';
                tools.tool_e.left_tool.style.display='none';
                tools.tool_e.right_tool.style.display='none';
                tools.sign_tool_state=0;
            }
        }

        var mouseup= function () {
            css_reInit(tools.sign_tool_state);
            document.getElementById('tool_move').style.display='none';
            $('#tool_move').unbind();
        }

        var x,y;
        var startX,startY;
        var left_start,top_start;
        e=e||arguments.callee.caller.arguments[1]||window.event;
        switch (s){
            case 1://mouseover
                $('#drag_shift').css('cursor', function () {
                    if(ClassConfInit.data.courseyoung){
                        return 'url(images/young_move.png) 15 4,auto';
                    }
                    else{
                        return 'url(images/move.png) 15 15,auto';
                    }
                });
                break;
            case 2://mouseout
                $('#drag_shift').css('cursor', function () {
                    if(ClassConfInit.data.courseyoung){
                        return 'url(images/young_normal.png) 25 15,auto';
                    }
                    else{
                        return 'url(images/normal.png) 0 0,auto';
                    }
                });
                break;
            case 3://mousedown
                $('#toolbar_left').css('width',$('#mainContainer').width()/800*50);
                $('#toolbar_right').css('width',$('#mainContainer').width()/800*50);
                $('#toolbar_bottom').css('height',$('#mainContainer').width()/800*50);
                startX= e.clientX;
                left_start=get_true($('#outerCenter').css('left'),1);
                startY= e.clientY;
                top_start=get_true($('#outerCenter').css('top'),1);
                document.getElementById('tool_move').style.display='block';
                bind_event($('#tool_move'));
                break;
            case 4:
                tools.sign_tool_state=0;
                mouseup();
                break;
            default :
                break;
        }

        function bind_event(target){
            target.unbind();
            target.bind('mousemove',mousemove);
            target.bind('mouseup',mouseup);
        }

    };

    var css_reInit= function (sign) {//根据后台设置的信息和位置设定
        var size=0;
        var firsttime=true;
        var sign_magic=false;
        var text_pad=0;
        var size_get= function (id) {
            if($('#'+id).css('display')=='block'){
                size+=(firsttime?15:25);
                firsttime=false;
            }
            return size+'px';
        }
        switch (sign){
            case  0://�ײ�
                $('#drag_shift').css({
                    'width':'10px',
                    'height':'30px',
                    'left':'0px',
                    'top':'1px'
                });

                $('#hand_line').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.pen)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left': function () {
                        return size_get('hand_line')
                    },
                    'top':'7px'
                });

                $('#hand_signLine').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.signpen)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left':function () {
                        return size_get('hand_signLine')
                    },
                    'top':'7px'
                });

                $('#hand_square').css({
                    'display':function () {
                        if(ClassConfInit.data.tools.rec)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left':function () {
                        return size_get('hand_square')
                    },
                    'top':'7px'
                });

                $('#hand_write').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.text)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left': function () {
                        text_pad=parseInt(size_get('hand_write').replace('px',''));
                        return text_pad;
                    },
                    'top':'7px'
                });

                $('#hand_rubber').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.rub||ClassConfInit.data.tools.newrub)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left': function () {
                        return size_get('hand_rubber')
                    },
                    'top':'7px'
                });

                $('#hand_drag').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.draft)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left': function () {
                        return size_get('hand_drag')
                    },
                    'top':'7px'
                });

                $('#hand_back').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.back)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left':function () {
                        return size_get('hand_back')
                    },
                    'top':'7px'
                });

                $('#hand_clear').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.clear)
                            return 'block';
                        else
                            return 'none';
                    },
                    'left':function () {
                        return size_get('hand_clear')
                    },
                    'top':'7px'
                });
                $('#hand_magic').css({
                    'display': function () {
                        if(ClassConfInit.data.name_login=='tea'&&ClassConfInit.data.Class1V1)
                        {
                            sign_magic=true;
                            return 'block';
                        }else{
                            return 'none';
                        }
                    },
                    'left': function () {
                        if(sign_magic){
                            return size_get('hand_magic');
                        }
                        return 0;
                    },
                    'top':'7px',
                });

                $('#outerCenter').css({
                    'width': function () {
                        return size+25;
                    },
                    'height':'32px',
                    'top': function () {
                        return $('#mainContainer').height()-$('#outerCenter').height()-4;
                    },
                    'left': function () {
                        return ($('#mainContainer').width()-$('#outerCenter').width())/2;
                    },
                    //'display': function () {
                    //    if(size==0){
                    //        return 'none';
                    //    }else{
                    //        return 'block';
                    //    }
                    //}
                });
                $('#Center_chose').css({
                    'width': function () {
                        return size+25;
                    },
                    'height':'24px',
                    'top': function () {
                        return $('#mainContainer').height()-$('#outerCenter').height()-4-$('#Center_chose').height();
                    },
                    'left': function () {
                        return ($('#mainContainer').width()-$('#outerCenter').width())/2;
                    }
                });
                $('#tool_bar_center').css({
                    'width': function () {
                        return size+25;
                    },
                    'height':'32px',
                    'background-image': 'url(./images/back_biger1.png)'
                });
                $('#chose_font').css({
                    'width':'48px',
                    'height':'24px',
                    'top':'0px',
                    'left':text_pad-12
                });
                $('#font_small').css({
                    'float':'left'
                });
                $('#font_big').css({
                    'float':'left'
                });
                if(ClassConfInit.data.conf.sign_tools){
                    tools.tool_e.bottom_tool.style.display='none';
                }
                break;
            case  1://��
                $('#drag_shift').css({
                    'height':'10px',
                    'width':'30px',
                    'top':'0px',
                    'left':'1px'
                });

                $('#hand_line').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.pen)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        return size_get('hand_line')
                    },
                    'left':'7px'
                });

                $('#hand_signLine').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.signpen)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        return size_get('hand_signLine')
                    },
                    'left':'7px'
                });

                $('#hand_square').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.rec)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        return size_get('hand_square')
                    },
                    'left':'7px'
                });

                $('#hand_write').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.text)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        text_pad=parseInt(size_get('hand_write').replace('px',''));
                        return text_pad;
                    },
                    'left':'7px'
                });

                $('#hand_rubber').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.rub||ClassConfInit.data.tools.newrub)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        return size_get('hand_rubber')
                    },
                    'left':'7px'
                });

                $('#hand_drag').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.draft)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        return size_get('hand_drag')
                    },
                    'left':'7px'
                });

                $('#hand_back').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.back)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top': function () {
                        return size_get('hand_back')
                    },
                    'left':'7px'
                });

                $('#hand_clear').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.clear)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        return size_get('hand_clear')
                    },
                    'left':'7px'
                });

                $('#hand_magic').css({
                    'display': function () {
                        if(ClassConfInit.data.name_login=='tea'&&ClassConfInit.data.Class1V1)
                        {
                            sign_magic=true;
                            return 'block';
                        }else{
                            return 'none';
                        }
                    },
                    'top':function () {
                        if(sign_magic){
                            return size_get('hand_magic');
                        }
                        return 0;
                    },
                    'left':'7px'
                });

                $('#outerCenter').css({
                    'height': function () {
                        return size+25;
                    },
                    'width':'32px',
                    'top':function () {
                        return ($('#mainContainer').height()-$('#outerCenter').height())/2;
                    },
                    'left': function () {
                        return 0;
                    },
                    //'display': function () {
                    //    if(size==0){
                    //        return 'none';
                    //    }else{
                    //        return 'block';
                    //    }
                    //}
                });
                $('#Center_chose').css({
                    'height': function () {
                        return size+25;
                    },
                    'width':'24px',
                    'top':function () {
                        return ($('#mainContainer').height()-$('#outerCenter').height())/2;
                    },
                    'left':'32px'
                });

                $('#tool_bar_center').css({
                    'float':'left',
                    'height':function () {
                        return size+25;
                    },
                    'width':'32px',
                    'background-image':'url(./images/back_biger2.png)'
                });

                $('#chose_font').css({
                    'width':'24px',
                    'height':'48px',
                    'left':'0px',
                    'top':text_pad-12
                });

                $('#font_small').css({
                    'float':'none'
                });
                $('#font_big').css({
                    'float':'none'
                });

                if(ClassConfInit.data.conf.sign_tools){
                    tools.tool_e.left_tool.style.display='none';
                }
                break;
            case  2://��
                $('#drag_shift').css({
                    'height':'5px',
                    'width':'30px',
                    'top':'7px',
                    'left':'1px'
                });

                $('#hand_line').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.pen)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_line'),
                    'left':'7px'
                });

                $('#hand_signLine').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.signpen)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_signLine'),
                    'left':'7px'
                });

                $('#hand_square').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.rec)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_square'),
                    'left':'7px'
                });

                $('#hand_write').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.text)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':function () {
                        text_pad=parseInt(size_get('hand_write').replace('px',''));
                        return text_pad;
                    },
                    'left':'7px'
                });

                $('#hand_rubber').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.rub||ClassConfInit.data.tools.newrub)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_rubber'),
                    'left':'7px'
                });

                $('#hand_drag').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.draft)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_drag'),
                    'left':'7px'
                });

                $('#hand_back').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.back)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_back'),
                    'left':'7px'
                });

                $('#hand_clear').css({
                    'display': function () {
                        if(ClassConfInit.data.tools.clear)
                            return 'block';
                        else
                            return 'none';
                    },
                    'top':size_get('hand_clear'),
                    'left':'7px'
                });

                $('#hand_magic').css({
                    'display': function () {
                        if(ClassConfInit.data.name_login=='tea'&&ClassConfInit.data.Class1V1)
                        {
                            sign_magic=true;
                            return 'block';
                        }else{
                            return 'none';
                        }
                    },
                    'top':function () {
                        if(sign_magic){
                            return size_get('hand_magic');
                        }
                        return 0;
                    },
                    'left':'7px',
                });

                $('#outerCenter').css({
                    'height':function () {
                        return size+25;
                    },
                    'width':'32px',
                    'top':function () {
                        return ($('#mainContainer').height()-$('#outerCenter').height())/2;
                    },
                    'left': function () {
                        return $('#mainContainer').width()-$('#outerCenter').width();
                    },
                    //'display': function () {
                    //    if(size==0){
                    //        return 'none';
                    //    }else{
                    //        return 'block';
                    //    }
                    //}
                });

                $('#Center_chose').css({
                    'height':function () {
                        return size+25;
                    },
                    'width':'24px',
                    'top':function () {
                        return ($('#mainContainer').height()-$('#outerCenter').height())/2;
                    },
                    'left': function () {
                        return $('#mainContainer').width()-$('#outerCenter').width()-24;
                    }
                });

                $('#tool_bar_center').css({
                    'float':'left',
                    'height':function () {
                        return size+25;
                    },
                    'width':'32px',
                    'background-image':'url(./images/back_biger2.png)'
                });

                $('#chose_font').css({
                    'width':'24px',
                    'height':'48px',
                    'left':'0px',
                    'top':text_pad-12
                });

                $('#font_small').css({
                    'float':'none'
                });

                $('#font_big').css({
                    'float':'none'
                });
                if(ClassConfInit.data.conf.sign_tools){
                    tools.tool_e.right_tool.style.display='none';
                }
                break;
            case  3://��pdf

                break;
        }
    };

    return{
        'BindEvent':ToolsEventBind,
        'next_previous':next_previous,
        'init':init_tool,
        'drafttool': function (s,e) {
            tray_pointer(s,e);
        },
        'css_reInit': function (sign) {
            css_reInit(sign);
        },
        'sign_tool_state':sign_tool_state,
        'tool_e':tool_e
    }
})();
function changePage(){
    if(ClassConfInit.data.name_login=='tea'){
        ClassConfInit.data.tea.pageNum=ClassConfInit.data.page.curpageNum;
    }
    WEBTools.draw('clear');
    $('#pageNumber').val(ClassConfInit.data.page.curpageNum);
    var num=ClassConfInit.data.page.curpageNum-1;
    if(num<10){
        num='0'+num;
    }
    $('#showDomain').attr('src','./src/ppt/'+num+'/index.html');

    if(ClassConfInit.data.name_login=='tea'&&(curState!=='') ){
        var obj={
            'TotalPage':ClassConfInit.data.page.count,
            'CurrentPage':ClassConfInit.data.page.curpageNum-1
        }
        comm_send.UpdatePage(JSON.stringify(obj));
    }
    var i= 0,j=5;
    var countp=0;
    var temArr=$('.item_title')[0].childNodes;
    for(;i<j;i++){
        if(i<ClassConfInit.data.page.curpageNum){
            countp+=parseInt(temArr[i].offsetWidth);
        }
        if(i==ClassConfInit.data.page.curpageNum-1){
            temArr[i].style.color='#ff8201';
        }else{
            temArr[i].style.color='#999999';
        }
    }
    $('.progress').find('.left').css('width',countp);
    $('.progress').find('.right').css('width',$('.item_title').width()-countp);
    if ((﻿ClassConfInit.data.page.curpageNum == 4||﻿ClassConfInit.data.page.curpageNum==5)&&(curState=='startClass')){
        parent.window.$('#tool_ppt_control').addClass('tool_ppt_practice');
    } else {
        parent.window.$('#tool_ppt_control').removeClass('tool_ppt_practice');
    }
}

var get_true= function (str,s) {
    if(s==0)
    {
        return parseInt(str.substring(0,str.indexOf('p')));
    }else{
        return parseFloat(str.substring(0,str.indexOf('p')));
    }
}

//���ڶ�̬�ĵ��ڹ�����
var tool= function () {
    if(ClassConfInit.data.conf.sign_tools){
        this.bottomContiner=document.getElementById('outerCenter');
        this.left_tool=document.getElementById('toolbar_left');
        this.right_tool=document.getElementById('toolbar_right');
        this.bottom_tool=document.getElementById('toolbar_bottom');
        document.getElementById('hand_line').style.backgroundPositionX='-42px';
    }
}

tool.prototype.tool_pencil= function () {
    WEBTools.draw('pencil');
}

tool.prototype.tool_signPen= function () {
    WEBTools.draw('sign_pencil');
}

tool.prototype.tool_square = function () {
    WEBTools.draw('square');
}

tool.prototype.tool_rubber = function () {
    WEBTools.draw('rubber');
}

tool.prototype.tool_write = function () {
    WEBTools.draw('write',false);
}

tool.prototype.tool_draft = function () {
    WEBTools.draw('draft');
}

tool.prototype.tool_back = function () {
    WEBTools.draw('back');
}

tool.prototype.tool_clear = function () {
    WEBTools.draw('clear');
}

tool.prototype.tool_next = function () {
    if(ClassConfInit.data.page.curpageNum<ClassConfInit.data.page.count){
        ClassConfInit.data.page.curpageNum=parseInt(ClassConfInit.data.page.curpageNum)+1;
        next_previous();
        commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
    }
}

tool.prototype.tool_pre = function () {
    if(ClassConfInit.data.page.curpageNum>1){
        ClassConfInit.data.page.curpageNum=parseInt(ClassConfInit.data.page.curpageNum)-1;
        next_previous();
        commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
    }
}

tool.prototype.tool_skip = function (num) {
    num=parseInt(num);

    if(num>=1&&num<=ClassConfInit.data.page.count){
        ClassConfInit.data.page.curpageNum=num;
        next_previous();
        commParIf.setpageEvent(ClassConfInit.data.page.curpageNum);
    }else{
        $('#pageNumber').val(ClassConfInit.data.page.curpageNum);
    }
}

tool.prototype.tool_update = function () {
    var temdata=ClassConfInit.data;

    temdata.page.curpageNum=parseInt(temdata.tea.pageNum);
    next_previous();
    commParIf.setpageEvent(temdata.tea.pageNum);
}

//��ʾ�������ع�����
tool.prototype.display_tool= function (type) {
    if(!type){
        this.bottomContiner.style.display='none';
    }
    else
    {
        this.bottomContiner.style.display='block';
    }
}

var next_previous=function(){
    var temdata=ClassConfInit.data;
    if(temdata.name_login=='tea') {//�������ʦ
        temdata.tea.pageNum=temdata.page.curpageNum;
    }else if(constants.STUTYPE.indexOf(temdata.name_login)!=-1) {//ѧ��
        if(temdata.page.curpageNum==temdata.tea.pageNum)//�����ѧ���˷�ҳ������
        {
            if(temdata.conf.sign_page){//����������ģ��
                $('#update_tea').css('display','none');
            }
        }else{
            if(temdata.conf.sign_page){
                $('#update_tea').css('display','block');
            }
        }
    }
    if(temdata.conf.sign_page) {//����������ģ��
        $('#pageNumber').val(temdata.page.curpageNum);
    }

    if(temdata.conf.sign_draw){//������ڻ���
        WEBTools.clearConText(1);
        $('#input').css('display','none');
        if(temdata.name_login=='tea'){//�������ʦ
            WEBTools.draw('clear');
        }else if(constants.STUTYPE.indexOf(temdata.name_login)!=-1){//ѧ��
            if(temdata.page.curpageNum==temdata.tea.pageNum)//�����ѧ���˷�ҳ������
            {
                if(ClassConfInit.data.tea.login&&ClassConfInit.data.candraw){//Ϊ�˱任�����ʽ
                    if(WEBTools.last_handle!='write'){
                        WEBTools.draw(WEBTools.last_handle);
                    }else
                    {
                        WEBTools.draw(WEBTools.last_handle,false);
                    }
                }
                if(temdata.Class1V1&&temdata.tea.login&&temdata.conf.sign_tools){//����������ģ��
                    tools.css_reInit(tools.sign_tool_state);
                }
                $('#update_tea').css('display','none');
                WEBTools.repaint();
            }else{
                if(temdata.conf.sign_tools){//����������ģ��
                    $('#outerCenter').css('display','none');
                }
                if(ClassConfInit.data.tea.login){//Ϊ�˱任��ʽ
                    if(ClassConfInit.data.courseyoung){
                        $('#canvas_bak').css('cursor','url(images/young_normal.png) 25 15,auto');
                    }else{
                        $('#canvas_bak').css('cursor','url(images/normal.png) 0 0,auto');
                    }
                }
            }
        }
    }
};

//��̬����������������div
tool.prototype.resize_tool= function () {
    //ȡpdf��ʾ�����
    var wid=$('#mainContainer').width();
    var hei=$('#mainContainer').height();
    //ȡpdf��ʾ���Ĺ������
    this.left_tool.style.width=ClassConfInit.data.canvas.width/800*80+'px';
    this.right_tool.style.width=ClassConfInit.data.canvas.width/800*80+'px';
    this.bottom_tool.style.height=ClassConfInit.data.canvas.width/800*80+'px';
    this.left_tool.style.display='none';
    this.right_tool.style.display='none';
    this.bottom_tool.style.display='none';

    if(ClassConfInit.data.tea.login){
        switch (tools.sign_tool_state){
            case  0://�ײ�
                $('#outerCenter').css({
                    'top': function () {
                        return $('#mainContainer').height()-$('#outerCenter').height()-4;
                    },
                    'left': function () {
                        return (wid-$('#outerCenter').width())/2;
                    }
                });
                $('#Center_chose').css({
                    'top':function () {
                        return $('#mainContainer').height()-$('#outerCenter').height()-$('#Center_chose');
                    },
                    'left': function () {
                        return (wid-$('#outerCenter').width())/2;
                    }
                });
                break;
            case  1://��
                $('#outerCenter').css({
                    'top':function () {
                        return (hei-$('#outerCenter').height())/2;
                    },
                    'left': function () {
                        return 0;
                    }
                });
                $('#Center_chose').css({
                    'top':function () {
                        return (hei-$('#outerCenter').height())/2;
                    },
                    'left':'32px'
                })
                break;
            case  2://��
                $('#outerCenter').css({
                    'top':function () {
                        return (hei-$('#tool_bar_center').height())/2;
                    },
                    'left': function () {
                        return ClassConfInit.data.course.width-$('#outerCenter').width();
                    }
                });
                $('#Center_chose').css({
                    'top':function () {
                        return (hei-$('#outerCenter').height())/2;
                    },
                    'left': function () {
                        return ClassConfInit.data.course.width-$('#outerCenter').width()-24;
                    }
                })
                break;
            case  3://��pdf

                break;
        }
    }else
    {
        $('#outerCenter').css('display','none');
    }


}

//��̬��ť��
var tool_three= function () {

}
tool_three.prototype.getTarget=function(e,t,s){
    this.e= e.target;
    this.ce= e.currentTarget;
    this.s=s;
    this.type=t;
    if(this.e.id!='tool_bar_center')
        this.listener();
}
tool_three.prototype.listener= function () {
    switch (this.type){
        case 'down':
            if(this.e.id=='drag_shift')
                tools.drafttool(3);
            else{
                if(this.e.id=='hand_back'||this.e.id=='hand_clear'){
                    this.change(0-2*this.s);
                    this.e.style.backgroundPositionX='0px';
                }else if(this.e.id=='hand_magic'){
                    this.e.style.backgroundPositionX='-44px';
                    comm_send.MagicImage(JSON.stringify({'left':parseInt($('#hand_magic').offset().left)+11,'top':parseInt($('#hand_magic').offset().top)+11,'ori':tools.sign_tool_state}));
                }else if(this.ce.id=='tool_bar_center'){
                    this.init_containerTool();
                    this.change(0-2*this.s);
                }
                else
                    this.change(0-2*this.s);
            }
            break;
        case 'over':
            if(this.e.id=='drag_shift')
                tools.drafttool(1);
            else if(this.e.id=='hand_magic'){
                this.e.style.backgroundPositionX='-22px';
            }else{
                this.change(0-this.s);
            }
            break;
        case 'out':
            if(this.e.id=='drag_shift')
                tools.drafttool(2);
            else if(this.e.id=='hand_magic'){
                this.e.style.backgroundPositionX='0px';
            }else {
                this.change(0);
            }
            break;
    }
}
tool_three.prototype.init_containerTool= function () {
    var tar=document.getElementById('tool_bar_center').childNodes;
    for(var i= 1,j=tar.length;i<j;i++){
        tar[i].style.backgroundPositionX='0px';
    }
}
tool_three.prototype.change= function (s) {
    if(get_true(this.e.style.backgroundPositionX,0)>=-40||this.e.style.backgroundPositionX=='')
        this.e.style.backgroundPositionX=s+"px";
}
